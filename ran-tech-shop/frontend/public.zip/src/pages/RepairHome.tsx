import { useEffect, useRef, useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';
import api from '../utils/api';
import type { RepairReview } from '../types';

gsap.registerPlugin(ScrollTrigger);

// Constants
const COLORS = {
  primary: '#F7B500',
  secondary: '#FF6B35',
  accent: '#7C3AED',
  highlight: '#06B6D4',
  dark: '#0A0A0B',
} as const;

const SERVICES = [
  { icon: '💻', title: 'Laptop Repair', description: 'Screen replacement, keyboard repair, battery replacement, and more.', price: 'From Rs. 500' },
  { icon: '🖥️', title: 'Desktop Repair', description: 'Hardware upgrades, troubleshooting, virus removal, and optimization.', price: 'From Rs. 400' },
  { icon: '📱', title: 'Phone Repair', description: 'Screen repair, battery replacement, water damage recovery.', price: 'From Rs. 300' },
  { icon: '🖥️', title: 'Monitor Repair', description: 'Dead pixels, backlight issues, power problems fixed.', price: 'From Rs. 600' },
  { icon: '⌨️', title: 'Peripheral Repair', description: 'Keyboards, mice, headsets, and other accessories.', price: 'From Rs. 200' },
  { icon: '🔧', title: 'Custom Builds', description: 'Custom PC building and hardware installation services.', price: 'From Rs. 1,000' }
] as const;

const STATS = [
  { value: '5000+', label: 'Devices Repaired' },
  { value: '98%', label: 'Success Rate' },
  { value: '24hrs', label: 'Avg Turnaround' },
  { value: '90 Days', label: 'Warranty' },
] as const;

const UPGRADES = [
  { icon: '🖥️', title: 'RAM Upgrade', description: 'Boost performance with DDR4/DDR5 RAM', price: 'From Rs. 2,000' },
  { icon: '💾', title: 'SSD Upgrade', description: 'Replace HDD with fast NVMe SSD', price: 'From Rs. 3,000' },
  { icon: '🔋', title: 'Battery Replacement', description: 'New battery installation for laptops', price: 'From Rs. 1,500' },
  { icon: '❄️', title: 'Cooling Upgrade', description: 'Better thermal management solution', price: 'From Rs. 1,000' },
] as const;

const PROCESS_STEPS = [
  { step: '01', title: 'Book Online', desc: 'Schedule a convenient time' },
  { step: '02', title: 'Drop Off', desc: 'Bring your device to us' },
  { step: '03', title: 'We Repair', desc: 'Expert technicians fix it' },
  { step: '04', title: 'Pick Up', desc: 'Get your device back' },
] as const;

const FEATURES = [
  { icon: '✓', title: 'Expert Technicians', desc: 'Certified professionals with years of experience' },
  { icon: '⚡', title: 'Fast Service', desc: '24-hour average turnaround on most repairs' },
  { icon: '🛡️', title: '90-Day Warranty', desc: 'Full warranty on all repair services' },
] as const;

const FALLBACK_REVIEWS = [
  { id: 1, name: 'Sarah M.', rating: 5, text: 'Fixed my MacBook screen in just 2 hours! Excellent service.', device: 'MacBook Pro' },
  { id: 2, name: 'John D.', rating: 5, text: 'Very professional team. My gaming PC runs better than ever.', device: 'Gaming Desktop' },
  { id: 3, name: 'Mike L.', rating: 5, text: 'Great prices and fast turnaround. Highly recommend!', device: 'Dell Laptop' },
] as const;

// Types
interface LocalReview {
  id: number;
  name: string;
  rating: number;
  text: string;
  device: string;
}

interface NewReviewForm {
  name: string;
  rating: number;
  text: string;
  device: string;
}

// Component
const RepairHome = () => {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);
  const lenisRef = useRef<Lenis | null>(null);
  
  const [reviews, setReviews] = useState<LocalReview[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const [newReview, setNewReview] = useState<NewReviewForm>({ 
    name: '', 
    rating: 5, 
    text: '', 
    device: '' 
  });

  // Fetch reviews
  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const { data } = await api.get('/repairs/reviews');
        const dbReviews = data.map((r: RepairReview, index: number) => ({
          id: index + 1,
          name: r.userName,
          rating: r.rating,
          text: r.comment,
          device: r.serviceName || r.serviceType,
        }));
        setReviews(dbReviews);
      } catch (err) {
        console.error('Failed to fetch reviews:', err);
        setReviews([...FALLBACK_REVIEWS]);
      } finally {
        setReviewsLoading(false);
      }
    };

    fetchReviews();
  }, []);

  // Setup smooth scroll and animations
  useEffect(() => {
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    lenisRef.current = lenis;
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add((time) => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);

    if (progressRef.current && containerRef.current) {
      gsap.to(progressRef.current, {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top top',
          end: 'bottom bottom',
          scrub: 0.3
        }
      });
    }

    return () => {
      lenis.destroy();
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
      gsap.ticker.remove((time) => lenis.raf(time * 1000));
    };
  }, []);

  // Handle review submission
  const handleAddReview = useCallback(async () => {
    if (!newReview.name || !newReview.text || !newReview.device) return;

    setSubmitLoading(true);
    try {
      await api.post('/repairs/reviews', {
        userName: newReview.name,
        serviceType: 'hardware',
        serviceName: newReview.device,
        rating: newReview.rating,
        comment: newReview.text,
      });
    } catch (err) {
      console.error('Failed to submit review:', err);
    } finally {
      setReviews(prev => [...prev, { id: prev.length + 1, ...newReview }]);
      setNewReview({ name: '', rating: 5, text: '', device: '' });
      setShowReviewForm(false);
      setSubmitLoading(false);
    }
  }, [newReview]);

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative min-h-screen overflow-x-hidden"
      style={{ backgroundColor: COLORS.dark }}
    >
      {/* Scroll Progress */}
      <div
        ref={progressRef}
        className="fixed top-0 left-0 right-0 h-1 z-[100] origin-left"
        style={{
          background: `linear-gradient(90deg, ${COLORS.primary}, ${COLORS.secondary})`,
          transform: 'scaleX(0)'
        }}
      />

      {/* Hero Section */}
      <HeroSection navigate={navigate} />

      {/* Stats Section */}
      <StatsSection />

      {/* Services Section */}
      <ServicesSection navigate={navigate} />

      {/* Process Section */}
      <ProcessSection />

      {/* Upgrades Section */}
      <UpgradesSection />

      {/* Reviews Section */}
      <ReviewsSection
        reviews={reviews}
        reviewsLoading={reviewsLoading}
        showReviewForm={showReviewForm}
        setShowReviewForm={setShowReviewForm}
        newReview={newReview}
        setNewReview={setNewReview}
        handleAddReview={handleAddReview}
        submitLoading={submitLoading}
      />

      {/* Features Section */}
      <FeaturesSection />

      {/* CTA Section */}
      <CTASection navigate={navigate} />
    </motion.div>
  );
};

// Sub-components
const HeroSection = ({ navigate }: { navigate: (path: string) => void }) => (
  <section className="relative min-h-screen flex items-center overflow-hidden bg-black">
    {/* Background Video on Right */}
    <div className="absolute right-0 top-0 w-1/2 h-full hidden lg:block">
      <video 
        className="w-full h-full object-cover opacity-50" 
        src="/videos/repair.mp4" 
        autoPlay 
        muted 
        loop 
        playsInline 
      />
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent" />
    </div>

    {/* Two Column Layout */}
    <div className="relative z-10 w-full max-w-7xl mx-auto px-6 lg:px-12 py-20">
      <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center min-h-screen lg:min-h-0">
        
        {/* Left Column - Content */}
        <motion.div 
          initial={{ opacity: 0, x: -30 }} 
          animate={{ opacity: 1, x: 0 }} 
          transition={{ duration: 0.8 }}
          className="space-y-10"
        >
          {/* Small Label */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            <span className="text-xs font-mono tracking-widest text-white/40 uppercase">
              Professional Device Repair
            </span>
          </motion.div>

          {/* Main Heading */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.8 }}
          >
            <h1 className="text-5xl sm:text-6xl lg:text-7xl xl:text-8xl font-light tracking-tight leading-none">
              <span className="block text-white font-extralight mb-3">Expert</span>
              <span className="block text-white font-bold">Repairs</span>
              <span className="block text-white/30 font-extralight mt-3">Done Right</span>
            </h1>
          </motion.div>

          {/* Description */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="text-base lg:text-lg text-white/60 font-light leading-relaxed max-w-lg"
          >
            Certified technicians. Premium parts. Precision service. 
            We restore your devices to peak performance with care and expertise.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.7 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <motion.button
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate('/repair')}
              className="group px-8 py-4 bg-white text-black font-medium text-sm tracking-wide flex items-center justify-center gap-3 transition-all"
            >
              <span>Schedule Repair</span>
              <svg className="w-4 h-4 group-hover:translate-x-1 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
              </svg>
            </motion.button>
            
            <motion.button
              whileHover={{ x: 4 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => navigate('/repair-contact')}
              className="px-8 py-4 bg-white/5 text-white font-medium text-sm tracking-wide hover:bg-white/10 transition-colors"
            >
              Get Quote
            </motion.button>
          </motion.div>

          {/* Features List */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.9 }}
            className="pt-8 space-y-4"
          >
            {[
              'Same-day service available',
              '90-day warranty included',
              'Certified technicians only'
            ].map((feature, idx) => (
              <motion.div
                key={feature}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 1 + idx * 0.1 }}
                className="flex items-center gap-3"
              >
                <div className="w-1 h-1 bg-white rounded-full" />
                <span className="text-sm text-white/50 font-light">{feature}</span>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>

        {/* Right Column - Stats & Info */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="space-y-12 lg:pl-12"
        >
          {/* Stats Grid */}
          <div className="grid grid-cols-2 gap-8">
            {[
              { value: '5000+', label: 'Devices Repaired' },
              { value: '24hrs', label: 'Avg Turnaround' },
              { value: '98%', label: 'Success Rate' },
              { value: '90d', label: 'Warranty Period' },
            ].map((stat, idx) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 + idx * 0.1 }}
                className="space-y-2"
              >
                <div className="text-4xl lg:text-5xl font-bold text-white tracking-tight">
                  {stat.value}
                </div>
                <div className="text-xs text-white/40 font-light uppercase tracking-wider">
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Divider */}
          <div className="h-px bg-white/10" />

          {/* Services Quick List */}
          <div className="space-y-6">
            <div className="text-xs font-mono tracking-widest text-white/40 uppercase">
              We Repair
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[
                'Laptops',
                'Desktops', 
                'Smartphones',
                'Tablets',
                'Monitors',
                'Peripherals'
              ].map((service, idx) => (
                <motion.div
                  key={service}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 + idx * 0.05 }}
                  className="text-sm text-white/60 font-light"
                >
                  {service}
                </motion.div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    </div>

    {/* Scroll Indicator */}
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1, y: [0, 6, 0] }}
      transition={{ 
        opacity: { delay: 1.5 },
        y: { repeat: Infinity, duration: 2, ease: "easeInOut" }
      }}
      className="absolute bottom-8 left-1/2 -translate-x-1/2 lg:left-auto lg:right-12 lg:translate-x-0"
    >
      <div className="flex flex-col items-center gap-2">
        <div className="w-px h-12 bg-white/20" />
        <span className="text-xs text-white/30 font-light rotate-90 origin-center whitespace-nowrap">Scroll</span>
      </div>
    </motion.div>
  </section>
);

const StatsSection = () => (
  <section className="py-20 border-y border-white/10">
    <div className="max-w-6xl mx-auto px-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
        {STATS.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            viewport={{ once: true }}
            className="text-center"
          >
            <div className="text-4xl md:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-primary to-highlight mb-2">
              {stat.value}
            </div>
            <div className="text-white/60">{stat.label}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const SectionHeader = ({ badge, title, highlightText, description }: { 
  badge: string; 
  title: string; 
  highlightText: string; 
  description?: string;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className="text-center mb-16"
  >
    <span className="inline-block px-4 py-2 rounded-full text-primary text-sm font-semibold mb-4 bg-primary/10 border border-primary/20">
      {badge}
    </span>
    <h2 className="text-4xl md:text-5xl font-black text-white mb-4">
      {title} <span className="text-primary">{highlightText}</span>
    </h2>
    {description && <p className="text-white/60 max-w-xl mx-auto">{description}</p>}
  </motion.div>
);

const ServicesSection = ({ navigate }: { navigate: (path: string) => void }) => (
  <section className="py-24">
    <div className="max-w-6xl mx-auto px-6">
      <SectionHeader 
        badge="OUR SERVICES" 
        title="What We" 
        highlightText="Repair" 
        description="From simple fixes to complex repairs, we handle it all with expertise"
      />
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES.map((service, index) => (
          <motion.div
            key={service.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            viewport={{ once: true }}
            whileHover={{ y: -10 }}
            onClick={() => navigate('/repair')}
            className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-2xl border border-white/10 hover:border-primary/50 transition-all group cursor-pointer"
          >
            <div className="text-5xl mb-4">{service.icon}</div>
            <h3 className="text-2xl font-bold text-white mb-2 group-hover:text-primary transition-colors">
              {service.title}
            </h3>
            <p className="text-white/60 mb-4">{service.description}</p>
            <div className="text-primary font-bold">{service.price}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ProcessSection = () => (
  <section className="py-24 bg-gradient-to-b from-transparent via-accent/5 to-transparent">
    <div className="max-w-6xl mx-auto px-6">
      <SectionHeader badge="PROCESS" title="How It" highlightText="Works" />
      <div className="grid md:grid-cols-4 gap-8">
        {PROCESS_STEPS.map((item, index) => (
          <motion.div
            key={item.step}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.15 }}
            viewport={{ once: true }}
            className="text-center relative"
          >
            <div className="text-6xl font-black text-primary/20 mb-4">{item.step}</div>
            <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
            <p className="text-white/60">{item.desc}</p>
            {index < 3 && (
              <div className="hidden md:block absolute top-10 right-0 translate-x-1/2 text-primary/30">→</div>
            )}
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const UpgradesSection = () => (
  <section className="py-24 bg-gradient-to-b from-accent/5 to-transparent">
    <div className="max-w-6xl mx-auto px-6">
      <SectionHeader 
        badge="HARDWARE UPGRADES" 
        title="Upgrade Your" 
        highlightText="Device"
        description="Looking to enhance your device's performance? We offer professional upgrades with quality components."
      />
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        {UPGRADES.map((upgrade, index) => (
          <motion.div
            key={upgrade.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            viewport={{ once: true }}
            whileHover={{ y: -10 }}
            className="bg-gradient-to-br from-gray-900 to-black p-6 rounded-2xl border border-white/10 hover:border-primary/50 transition-all group cursor-pointer"
          >
            <div className="text-5xl mb-4">{upgrade.icon}</div>
            <h3 className="text-xl font-bold text-white mb-2 group-hover:text-primary transition-colors">
              {upgrade.title}
            </h3>
            <p className="text-white/60 mb-4 text-sm">{upgrade.description}</p>
            <div className="text-primary font-bold">{upgrade.price}</div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const ReviewsSection = ({ 
  reviews, 
  reviewsLoading, 
  showReviewForm, 
  setShowReviewForm, 
  newReview, 
  setNewReview, 
  handleAddReview, 
  submitLoading 
}: {
  reviews: LocalReview[];
  reviewsLoading: boolean;
  showReviewForm: boolean;
  setShowReviewForm: (show: boolean) => void;
  newReview: NewReviewForm;
  setNewReview: (review: NewReviewForm) => void;
  handleAddReview: () => void;
  submitLoading: boolean;
}) => (
  <section className="py-24">
    <div className="max-w-6xl mx-auto px-6">
      <SectionHeader badge="CUSTOMER REVIEWS" title="What Customers" highlightText="Say" />

      <div className="grid md:grid-cols-3 gap-6 mb-12">
        {reviewsLoading ? (
          <div className="col-span-3 flex justify-center items-center py-12">
            <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : reviews.length === 0 ? (
          <div className="col-span-3 text-center py-12">
            <p className="text-white/50">No reviews yet. Be the first to share your experience!</p>
          </div>
        ) : (
          reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-2xl border border-white/10"
            >
              <div className="flex gap-1 mb-4">
                {[...Array(review.rating)].map((_, i) => (
                  <span key={i} className="text-yellow-400">⭐</span>
                ))}
              </div>
              <div className="text-sm text-primary/80 mb-2 font-semibold">{review.device}</div>
              <p className="text-white/80 mb-4 italic">"{review.text}"</p>
              <div className="text-primary font-bold">{review.name}</div>
            </motion.div>
          ))
        )}
      </div>

      {!showReviewForm ? (
        <div className="text-center">
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setShowReviewForm(true)}
            className="px-8 py-3 bg-gradient-to-r from-primary to-secondary text-dark font-bold rounded-lg text-lg"
          >
            Share Your Experience
          </motion.button>
        </div>
      ) : (
        <ReviewForm 
          newReview={newReview}
          setNewReview={setNewReview}
          handleAddReview={handleAddReview}
          setShowReviewForm={setShowReviewForm}
          submitLoading={submitLoading}
        />
      )}
    </div>
  </section>
);

const ReviewForm = ({
  newReview,
  setNewReview,
  handleAddReview,
  setShowReviewForm,
  submitLoading
}: {
  newReview: NewReviewForm;
  setNewReview: (review: NewReviewForm) => void;
  handleAddReview: () => void;
  setShowReviewForm: (show: boolean) => void;
  submitLoading: boolean;
}) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="max-w-2xl mx-auto bg-dark-200/50 border border-white/10 rounded-2xl p-8"
  >
    <h3 className="text-2xl font-bold text-white mb-6">Add Your Review</h3>
    <div className="space-y-4">
      <input
        type="text"
        placeholder="Your Name"
        value={newReview.name}
        onChange={(e) => setNewReview({ ...newReview, name: e.target.value })}
        className="w-full px-4 py-3 bg-dark-200 border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-primary"
      />
      <input
        type="text"
        placeholder="Device Model (e.g., MacBook Pro, Dell XPS)"
        value={newReview.device}
        onChange={(e) => setNewReview({ ...newReview, device: e.target.value })}
        className="w-full px-4 py-3 bg-dark-200 border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-primary"
      />
      <select
        value={newReview.rating}
        onChange={(e) => setNewReview({ ...newReview, rating: parseInt(e.target.value) })}
        className="w-full px-4 py-3 bg-dark-200 border border-white/10 rounded-lg text-white focus:outline-none focus:border-primary"
      >
        <option value="5">⭐⭐⭐⭐⭐ - Excellent</option>
        <option value="4">⭐⭐⭐⭐ - Good</option>
        <option value="3">⭐⭐⭐ - Average</option>
        <option value="2">⭐⭐ - Poor</option>
        <option value="1">⭐ - Very Poor</option>
      </select>
      <textarea
        placeholder="Share your experience..."
        value={newReview.text}
        onChange={(e) => setNewReview({ ...newReview, text: e.target.value })}
        rows={4}
        className="w-full px-4 py-3 bg-dark-200 border border-white/10 rounded-lg text-white placeholder-white/40 focus:outline-none focus:border-primary"
      />
      <div className="flex gap-4">
        <motion.button
          whileHover={{ scale: submitLoading ? 1 : 1.05 }}
          whileTap={{ scale: submitLoading ? 1 : 0.95 }}
          onClick={handleAddReview}
          disabled={submitLoading}
          className="flex-1 px-6 py-3 bg-gradient-to-r from-primary to-secondary text-dark font-bold rounded-lg disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {submitLoading ? (
            <>
              <div className="w-5 h-5 border-2 border-dark border-t-transparent rounded-full animate-spin" />
              Posting...
            </>
          ) : 'Post Review'}
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowReviewForm(false)}
          disabled={submitLoading}
          className="flex-1 px-6 py-3 border-2 border-white/20 text-white font-bold rounded-lg hover:border-primary/60 disabled:opacity-50"
        >
          Cancel
        </motion.button>
      </div>
    </div>
  </motion.div>
);

const FeaturesSection = () => (
  <section className="py-24">
    <div className="max-w-6xl mx-auto px-6">
      <SectionHeader badge="TESTIMONIALS" title="Why Choose" highlightText="Us" />
      <div className="grid md:grid-cols-3 gap-6">
        {FEATURES.map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            className="bg-gradient-to-br from-gray-900 to-black p-8 rounded-2xl border border-white/10"
          >
            <div className="text-4xl mb-4 text-primary">{item.icon}</div>
            <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
            <p className="text-white/60">{item.desc}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const CTASection = ({ navigate }: { navigate: (path: string) => void }) => (
  <section className="py-24">
    <div className="max-w-4xl mx-auto px-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        className="bg-gradient-to-br from-primary/20 to-highlight/20 p-12 rounded-3xl border border-primary/30 text-center relative overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 to-highlight/10" />
        <div className="relative z-10">
          <h2 className="text-4xl md:text-5xl font-black text-white mb-4">Need a Repair?</h2>
          <p className="text-white/60 text-xl mb-8 max-w-xl mx-auto">
            Book your appointment today and get your device fixed by our expert technicians.
          </p>
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => navigate('/repair')}
            className="px-10 py-4 bg-gradient-to-r from-primary to-highlight text-white font-bold rounded-lg text-lg shadow-lg shadow-primary/30"
          >
            Book Repair Now →
          </motion.button>
        </div>
      </motion.div>
    </div>
  </section>
);

export default RepairHome;
