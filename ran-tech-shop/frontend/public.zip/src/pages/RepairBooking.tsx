import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from '../store/authStore';
import { useOrdersStore } from '../store/ordersStore';
import { useAdminStore } from '../store/adminStore';
import Button from '../components/ui/Button';
import api from '../utils/api';
import type { Product } from '../types';

interface TimeSlot {
  id: string;
  time: string;
  available: boolean;
}

interface RepairBooking {
  id: string;
  date: string;
  timeSlot: string;
  status: string;
}

// Service categories for filtering
const serviceCategories = [
  { id: 'all', name: 'All Services', icon: '🔧' },
  { id: 'hardware', name: 'Hardware Repair', icon: '🔨' },
  { id: 'software', name: 'Software Services', icon: '💻' },
  { id: 'data', name: 'Data Services', icon: '💾' },
  { id: 'upgrade', name: 'Upgrades', icon: '⬆️' },
  { id: 'cleaning', name: 'Cleaning', icon: '🧹' },
];

const timeSlots: TimeSlot[] = [
  { id: '1', time: '09:00 AM - 10:00 AM', available: true },
  { id: '2', time: '10:00 AM - 11:00 AM', available: true },
  { id: '3', time: '11:00 AM - 12:00 PM', available: true },
  { id: '4', time: '12:00 PM - 01:00 PM', available: false },
  { id: '5', time: '02:00 PM - 03:00 PM', available: true },
  { id: '6', time: '03:00 PM - 04:00 PM', available: true },
  { id: '7', time: '04:00 PM - 05:00 PM', available: true },
  { id: '8', time: '05:00 PM - 06:00 PM', available: true },
];

// Service type to icon mapping
const serviceTypeIcons: Record<string, string> = {
  'hardware': '🔨',
  'software': '💻',
  'data': '💾',
  'upgrade': '⬆️',
  'cleaning': '🧹',
  'screen': '📱',
  'battery': '🔋',
  'keyboard': '⌨️',
  'diagnostic': '🔍',
};

const RepairBooking: React.FC = () => {
  const { user, isAuthenticated } = useAuthStore();
  const { addBooking } = useOrdersStore();
  const { getBlockedSlotsForDate } = useAdminStore();
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState<string>('');
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [issueDescription, setIssueDescription] = useState('');
  const [customerName, setCustomerName] = useState(user?.name || '');
  const [customerEmail, setCustomerEmail] = useState(user?.email || '');
  const [customerPhone, setCustomerPhone] = useState('');
  const [availableSlots, setAvailableSlots] = useState<TimeSlot[]>(timeSlots);
  const [_existingBookings, setExistingBookings] = useState<RepairBooking[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [bookingTicketId, setBookingTicketId] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [services, setServices] = useState<Product[]>([]);
  const [servicesLoading, setServicesLoading] = useState(true);

  // Fetch services from database
  useEffect(() => {
    const fetchServices = async () => {
      setServicesLoading(true);
      try {
        const response = await api.get('/repairs/services');
        if (response.data && response.data.services) {
          setServices(response.data.services);
        } else if (response.data && Array.isArray(response.data)) {
          setServices(response.data);
        }
      } catch (err) {
        console.error('Failed to fetch services:', err);
        setError('Failed to load services. Please try again.');
      } finally {
        setServicesLoading(false);
      }
    };

    fetchServices();
  }, []);

  // Filter services by category
  const normalizePrice = (price: number | string | null | undefined) => {
    const numeric = typeof price === 'number' ? price : Number(price);
    return Number.isFinite(numeric) ? numeric : 0;
  };

  const formatPrice = (price: number | string | null | undefined) =>
    normalizePrice(price).toLocaleString('en-LK');

  // Map category to serviceType values
  const getCategoryServiceTypes = (category: string): string[] => {
    switch (category) {
      case 'hardware':
        return ['repair', 'hardware'];
      case 'software':
        return ['software'];
      case 'data':
        return ['data'];
      case 'upgrade':
        return ['upgrade'];
      case 'cleaning':
        return ['cleaning', 'maintenance'];
      default:
        return [];
    }
  };

  const filteredServices = selectedCategory === 'all'
    ? services
    : services.filter((s) => getCategoryServiceTypes(selectedCategory).includes(s.serviceType || ''));

  // Get selected service objects
  const getSelectedServiceObjects = () => {
    return services.filter(s => selectedServices.includes(s.id));
  };

  // Calculate total price
  const calculateTotal = () => {
    return getSelectedServiceObjects().reduce(
      (total, service) => total + normalizePrice(service.price),
      0
    );
  };

  // Toggle service selection
  const toggleService = (serviceId: string) => {
    if (selectedServices.includes(serviceId)) {
      setSelectedServices(prev => prev.filter(id => id !== serviceId));
    } else {
      setSelectedServices(prev => [...prev, serviceId]);
    }
  };

  // Generate next 14 days for date selection
  const getAvailableDates = () => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= 14; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      // Skip Sundays
      if (date.getDay() !== 0) {
        dates.push({
          value: date.toISOString().split('T')[0],
          label: date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' }),
          dayName: date.toLocaleDateString('en-US', { weekday: 'long' }),
        });
      }
    }
    return dates;
  };

  const availableDates = getAvailableDates();

  // Fetch existing bookings and available slots
  useEffect(() => {
    const fetchBookings = async () => {
      if (!selectedDate) return;
      
      try {
        const response = await api.get(`/repairs/availability?date=${selectedDate}`);
        if (response.data.slots) {
          setAvailableSlots(response.data.slots);
        }
      } catch (err) {
        console.log('Using default time slots');
        const dateHash = selectedDate.split('-').reduce((a, b) => a + parseInt(b), 0);
        const simulatedSlots = timeSlots.map((slot, index) => ({
          ...slot,
          available: (dateHash + index) % 3 !== 0,
        }));
        setAvailableSlots(simulatedSlots);
      }
    };

    fetchBookings();
  }, [selectedDate]);

  // Fetch user's existing bookings
  useEffect(() => {
    const fetchUserBookings = async () => {
      if (!isAuthenticated) return;
      
      try {
        const response = await api.get('/repairs/my-bookings');
        setExistingBookings(response.data.bookings || []);
      } catch (err) {
        console.log('No existing bookings found');
      }
    };

    fetchUserBookings();
  }, [isAuthenticated]);

  const handleSubmit = async () => {
    setIsLoading(true);
    setError(null);

    try {
      const bookingData = {
        date: selectedDate,
        timeSlot: selectedTimeSlot,
        services: selectedServices,
        totalAmount: calculateTotal(),
        issueDescription,
        customerName,
        customerEmail,
        customerPhone,
      };

      // Save to local store first
      const selectedServiceNames = getSelectedServiceObjects().map(s => s.name);
      const ticketId = addBooking({
        deviceType: 'Laptop', // Default, could be made selectable
        deviceModel: 'Device', // Could be added as form field
        issueDescription: issueDescription || 'General repair service',
        bookedDate: selectedDate,
        totalCost: calculateTotal(),
        services: selectedServiceNames,
        timeSlot: selectedTimeSlot,
        customerName,
        customerEmail,
        customerPhone,
      });
      setBookingTicketId(ticketId);

      // Try to save to backend as well
      try {
        const response = await api.post('/repairs/book', bookingData);
        if (response.data.success) {
          setBookingSuccess(true);
        }
      } catch (apiErr) {
        // Backend save failed, but local save succeeded
        console.log('Backend save failed, but booking saved locally');
      }

      setBookingSuccess(true);
    } catch (err: any) {
      console.error('Booking failed:', err);
      setError('Failed to create booking. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const resetForm = () => {
    setStep(1);
    setSelectedDate('');
    setSelectedTimeSlot('');
    setSelectedCategory('all');
    setSelectedServices([]);
    setIssueDescription('');
    setBookingSuccess(false);
    setBookingTicketId('');
    setError(null);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 },
  };

  // Success state
  if (bookingSuccess) {
    return (
      <div className="min-h-screen bg-dark pt-24 pb-16">
        <div className="container mx-auto px-4">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="max-w-2xl mx-auto text-center"
          >
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: 'spring', duration: 0.8 }}
              className="w-24 h-24 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-8"
            >
              <svg className="w-12 h-12 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </motion.div>

            <h1 className="text-4xl font-bold text-white mb-4">Booking Confirmed!</h1>
            <p className="text-white/60 text-lg mb-2">
              Your repair appointment has been scheduled successfully.
            </p>
            <p className="text-primary text-lg font-semibold mb-8">
              Job Sheet #: {bookingTicketId}
            </p>

            <div className="bg-dark-200 rounded-2xl p-8 border border-white/10 mb-8">
              <h3 className="text-xl font-semibold text-white mb-6">Appointment Details</h3>
              <div className="grid grid-cols-2 gap-4 text-left">
                <div>
                  <p className="text-white/40 text-sm">Date</p>
                  <p className="text-white font-medium">
                    {availableDates.find(d => d.value === selectedDate)?.label}
                  </p>
                </div>
                <div>
                  <p className="text-white/40 text-sm">Time</p>
                  <p className="text-white font-medium">{selectedTimeSlot}</p>
                </div>
                <div className="col-span-2">
                  <p className="text-white/40 text-sm mb-2">Services</p>
                  {getSelectedServiceObjects().map(service => {
                    const icon = serviceTypeIcons[service.serviceType || 'hardware'] || '🔧';
                    return (
                      <div key={service.id} className="flex justify-between items-center py-1">
                        <span className="text-white">{icon} {service.name}</span>
                        <span className="text-primary">Rs. {formatPrice(service.price)}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="col-span-2 pt-4 border-t border-white/10">
                  <div className="flex justify-between items-center">
                    <span className="text-white font-semibold">Total</span>
                    <span className="text-primary text-xl font-bold">Rs. {formatPrice(calculateTotal())}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex gap-4 justify-center">
              <Button variant="secondary" onClick={resetForm}>
                Book Another
              </Button>
              <Button variant="primary" onClick={() => window.location.href = '/'}>
                Go to Home
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark pt-24 pb-16">
      {/* Header Section */}
      <section className="relative overflow-hidden py-12">
        <motion.div
          className="absolute inset-0"
          style={{
            background: 'radial-gradient(ellipse at center, rgba(247,181,0,0.1) 0%, transparent 70%)',
          }}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />

        <div className="container mx-auto px-4 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center max-w-3xl mx-auto"
          >
            <motion.span
              className="inline-block px-4 py-2 rounded-full text-primary text-sm font-semibold mb-4 bg-primary/10 border border-primary/20"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              REPAIR SERVICE
            </motion.span>
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Book Your{' '}
              <span className="text-primary">Repair</span> Appointment
            </h1>
            <p className="text-white/60 text-lg">
              Choose from our wide range of services. Select multiple services for a complete solution.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Progress Steps */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center justify-between mb-12">
              {[
                { num: 1, label: 'Select Date & Time' },
                { num: 2, label: 'Choose Services' },
                { num: 3, label: 'Contact Info' },
                { num: 4, label: 'Confirm' },
              ].map((s, index) => (
                <React.Fragment key={s.num}>
                  <motion.div
                    className="flex flex-col items-center"
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <motion.div
                      className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg transition-all duration-300 ${
                        step >= s.num
                          ? 'bg-primary text-dark'
                          : 'bg-dark-300 text-white/40'
                      }`}
                      whileHover={{ scale: 1.1 }}
                    >
                      {step > s.num ? (
                        <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                      ) : (
                        s.num
                      )}
                    </motion.div>
                    <span className={`text-sm mt-2 hidden md:block ${step >= s.num ? 'text-white' : 'text-white/40'}`}>
                      {s.label}
                    </span>
                  </motion.div>
                  {index < 3 && (
                    <div className={`flex-1 h-1 mx-4 rounded-full transition-all duration-300 ${
                      step > s.num ? 'bg-primary' : 'bg-dark-300'
                    }`} />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-8">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <AnimatePresence mode="wait">
              {/* Step 1: Date & Time Selection */}
              {step === 1 && (
                <motion.div
                  key="step1"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, x: -100 }}
                  className="space-y-8 max-w-4xl mx-auto"
                >
                  {/* Date Selection */}
                  <motion.div variants={itemVariants}>
                    <h3 className="text-xl font-semibold text-white mb-4">Select Date</h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
                      {availableDates.map((date) => (
                        <motion.button
                          key={date.value}
                          onClick={() => setSelectedDate(date.value)}
                          className={`p-4 rounded-xl border transition-all duration-300 ${
                            selectedDate === date.value
                              ? 'bg-primary text-dark border-primary'
                              : 'bg-dark-200 text-white border-white/10 hover:border-primary/50'
                          }`}
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          <div className="text-sm opacity-70">{date.dayName.slice(0, 3)}</div>
                          <div className="font-bold">{date.label.split(' ')[1]} {date.label.split(' ')[2]}</div>
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>

                  {/* Time Slot Selection */}
                  {selectedDate && (
                    <motion.div
                      variants={itemVariants}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                    >
                      <h3 className="text-xl font-semibold text-white mb-4">Select Time Slot</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                        {availableSlots.map((slot) => {
                          const blockedSlots = getBlockedSlotsForDate(selectedDate);
                          const isBlockedByAdmin = blockedSlots.includes(slot.time);
                          const isAvailable = slot.available && !isBlockedByAdmin;
                          
                          return (
                            <motion.button
                              key={slot.id}
                              onClick={() => isAvailable && setSelectedTimeSlot(slot.time)}
                              disabled={!isAvailable}
                              className={`p-4 rounded-xl border transition-all duration-300 ${
                                !isAvailable
                                  ? 'bg-dark-300/50 text-white/30 border-white/5 cursor-not-allowed'
                                  : selectedTimeSlot === slot.time
                                  ? 'bg-primary text-dark border-primary'
                                  : 'bg-dark-200 text-white border-white/10 hover:border-primary/50'
                              }`}
                              whileHover={isAvailable ? { scale: 1.02 } : {}}
                              whileTap={isAvailable ? { scale: 0.98 } : {}}
                            >
                              <div className="font-medium">{slot.time}</div>
                              {!slot.available && (
                                <div className="text-xs mt-1 text-red-400">Booked</div>
                              )}
                              {slot.available && isBlockedByAdmin && (
                                <div className="text-xs mt-1 text-amber-400">Unavailable</div>
                              )}
                            </motion.button>
                          );
                        })}
                      </div>
                    </motion.div>
                  )}


                  {/* Shop Hours Info */}
                  <motion.div
                    variants={itemVariants}
                    className="bg-gradient-to-br from-dark-200 to-dark-300 rounded-2xl p-6 border border-white/10"
                  >
                    <h4 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                      <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                      </svg>
                      Shop Hours
                    </h4>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <p className="text-white/40">Monday - Friday</p>
                        <p className="text-white">9:00 AM - 6:00 PM</p>
                      </div>
                      <div>
                        <p className="text-white/40">Saturday</p>
                        <p className="text-white">10:00 AM - 4:00 PM</p>
                      </div>
                      <div>
                        <p className="text-white/40">Sunday</p>
                        <p className="text-red-400">Closed</p>
                      </div>
                    </div>
                  </motion.div>

                  <motion.div variants={itemVariants} className="flex justify-end">
                    <Button
                      variant="primary"
                      onClick={() => setStep(2)}
                      disabled={!selectedDate || !selectedTimeSlot}
                    >
                      Continue
                      <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                      </svg>
                    </Button>
                  </motion.div>
                </motion.div>
              )}

              {/* Step 2: Service Selection - Shop-like Grid */}
              {step === 2 && (
                <motion.div
                  key="step2"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, x: -100 }}
                  className="space-y-8"
                >
                  {/* Category Filter Tabs */}
                  <motion.div variants={itemVariants}>
                    <div className="flex flex-wrap gap-3 justify-center">
                      {serviceCategories.map((cat) => (
                        <motion.button
                          key={cat.id}
                          onClick={() => setSelectedCategory(cat.id)}
                          className={`px-6 py-3 rounded-full font-medium transition-all duration-300 flex items-center gap-2 ${
                            selectedCategory === cat.id
                              ? 'bg-primary text-dark'
                              : 'bg-dark-200 text-white/70 hover:text-white border border-white/10 hover:border-primary/50'
                          }`}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          <span>{cat.icon}</span>
                          <span>{cat.name}</span>
                        </motion.button>
                      ))}
                    </div>
                  </motion.div>

                  {/* Service Cards Grid */}
                  <motion.div variants={itemVariants}>
                    <h3 className="text-xl font-semibold text-white mb-2">Select Services</h3>
                    <p className="text-white/50 mb-6">Click on services to select them. You can choose multiple services.</p>
                    
                    {servicesLoading ? (
                      <div className="flex justify-center items-center py-20">
                        <div className="w-12 h-12 border-4 border-primary border-t-transparent rounded-full animate-spin" />
                      </div>
                    ) : filteredServices.length === 0 ? (
                      <div className="text-center py-20">
                        <p className="text-white/50">No services found in this category.</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                        {filteredServices.map((service) => {
                          const isSelected = selectedServices.includes(service.id);
                          const icon = serviceTypeIcons[service.serviceType || 'hardware'] || '🔧';
                          return (
                            <motion.div
                              key={service.id}
                              className={`relative rounded-2xl overflow-hidden border-2 transition-all duration-300 cursor-pointer ${
                                isSelected ? 'border-primary shadow-lg shadow-primary/20' : 'border-white/10 hover:border-white/30'
                              }`}
                              whileHover={{ y: -5 }}
                              onClick={() => toggleService(service.id)}
                            >
                              {/* Selection Checkbox */}
                              <div className="absolute top-4 right-4 z-10">
                                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                                  isSelected ? 'bg-primary border-primary' : 'border-white/50 bg-dark/50'
                                }`}>
                                  {isSelected && (
                                    <svg className="w-4 h-4 text-dark" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                                    </svg>
                                  )}
                                </div>
                              </div>

                              {/* Service Image */}
                              <div 
                                className="h-40 bg-cover bg-center"
                                style={{ backgroundImage: `url(${service.image})` }}
                              >
                                <div className="w-full h-full bg-gradient-to-t from-dark to-transparent" />
                              </div>

                              {/* Service Info */}
                              <div className="p-4 bg-dark-200">
                                <div className="flex items-center gap-2 mb-2">
                                  <span className="text-2xl">{icon}</span>
                                  <h4 className="font-semibold text-white">{service.name}</h4>
                                </div>
                                <p className="text-white/50 text-sm mb-3 line-clamp-2">{service.description}</p>
                                
                                {/* Price */}
                                <div className="text-primary font-bold text-lg">
                                  Rs. {formatPrice(service.price)}
                                </div>

                                {/* Service specs if available */}
                                {service.specs && Object.keys(service.specs).length > 0 && (
                                  <div className="mt-2 text-xs text-white/40">
                                    {Object.entries(service.specs as Record<string, string>).slice(0, 2).map(([key, value]) => (
                                      <div key={key} className="flex justify-between">
                                        <span>{key}:</span>
                                        <span className="text-white/60">{value}</span>
                                      </div>
                                    ))}
                                  </div>
                                )}
                              </div>
                            </motion.div>
                          );
                        })}
                      </div>
                    )}
                  </motion.div>

                  {/* Selected Services Summary */}
                  {selectedServices.length > 0 && (
                    <motion.div
                      variants={itemVariants}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="bg-gradient-to-br from-primary/10 to-dark-200 rounded-2xl p-6 border border-primary/30"
                    >
                      <h4 className="text-lg font-semibold text-white mb-4">Selected Services ({selectedServices.length})</h4>
                      <div className="space-y-3">
                        {getSelectedServiceObjects().map(service => {
                          const icon = serviceTypeIcons[service.serviceType || 'hardware'] || '🔧';
                          return (
                            <div key={service.id} className="flex justify-between items-center py-2 border-b border-white/10 last:border-0">
                              <div className="flex items-center gap-3">
                                <span className="text-xl">{icon}</span>
                                <div>
                                  <p className="text-white font-medium">{service.name}</p>
                                  <p className="text-white/50 text-sm">{service.serviceType || 'Service'}</p>
                                </div>
                              </div>
                              <div className="text-right">
                                <span className="text-primary font-bold">
                                  Rs. {formatPrice(service.price)}
                                </span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      <div className="flex justify-between items-center mt-4 pt-4 border-t border-white/20">
                        <span className="text-white font-semibold text-lg">Total Estimate</span>
                        <span className="text-primary font-bold text-2xl">Rs. {formatPrice(calculateTotal())}</span>
                      </div>
                    </motion.div>
                  )}

                  {/* Additional Notes */}
                  <motion.div variants={itemVariants}>
                    <h3 className="text-xl font-semibold text-white mb-4">Additional Notes (Optional)</h3>
                    <textarea
                      value={issueDescription}
                      onChange={(e) => setIssueDescription(e.target.value)}
                      placeholder="Any additional details about your device or the issue..."
                      className="w-full h-32 bg-dark-200 border border-white/10 rounded-xl p-4 text-white placeholder-white/30 focus:border-primary focus:outline-none resize-none"
                    />
                  </motion.div>

                  <motion.div variants={itemVariants} className="flex justify-between">
                    <Button variant="secondary" onClick={() => setStep(1)}>
                      <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                      </svg>
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      onClick={() => setStep(3)}
                      disabled={selectedServices.length === 0}
                    >
                      Continue
                      <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                      </svg>
                    </Button>
                  </motion.div>
                </motion.div>
              )}

              {/* Step 3: Contact Information */}
              {step === 3 && (
                <motion.div
                  key="step3"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, x: -100 }}
                  className="space-y-8 max-w-4xl mx-auto"
                >
                  <motion.div variants={itemVariants}>
                    <h3 className="text-xl font-semibold text-white mb-6">Your Contact Information</h3>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-white/60 text-sm mb-2">Full Name</label>
                        <input
                          type="text"
                          value={customerName}
                          onChange={(e) => setCustomerName(e.target.value)}
                          placeholder="John Doe"
                          className="w-full bg-dark-200 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:border-primary focus:outline-none"
                        />
                      </div>
                      <div>
                        <label className="block text-white/60 text-sm mb-2">Email Address</label>
                        <input
                          type="email"
                          value={customerEmail}
                          onChange={(e) => setCustomerEmail(e.target.value)}
                          placeholder="john@example.com"
                          className="w-full bg-dark-200 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:border-primary focus:outline-none"
                        />
                      </div>
                      <div className="md:col-span-2">
                        <label className="block text-white/60 text-sm mb-2">Phone Number</label>
                        <input
                          type="tel"
                          value={customerPhone}
                          onChange={(e) => setCustomerPhone(e.target.value)}
                          placeholder="+66 123-456-789"
                          className="w-full bg-dark-200 border border-white/10 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:border-primary focus:outline-none"
                        />
                      </div>
                    </div>
                  </motion.div>

                  <motion.div variants={itemVariants} className="flex justify-between">
                    <Button variant="secondary" onClick={() => setStep(2)}>
                      <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                      </svg>
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      onClick={() => setStep(4)}
                      disabled={!customerName || !customerEmail || !customerPhone}
                    >
                      Continue
                      <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                      </svg>
                    </Button>
                  </motion.div>
                </motion.div>
              )}

              {/* Step 4: Confirmation */}
              {step === 4 && (
                <motion.div
                  key="step4"
                  variants={containerVariants}
                  initial="hidden"
                  animate="visible"
                  exit={{ opacity: 0, x: -100 }}
                  className="space-y-8 max-w-4xl mx-auto"
                >
                  <motion.div variants={itemVariants}>
                    <h3 className="text-xl font-semibold text-white mb-6">Review Your Booking</h3>
                    
                    <div className="bg-gradient-to-br from-dark-200 to-dark-300 rounded-2xl p-8 border border-white/10">
                      <div className="grid md:grid-cols-2 gap-6 mb-6">
                        <div>
                          <p className="text-white/40 text-sm mb-1">Date</p>
                          <p className="text-white font-medium text-lg">
                            {availableDates.find(d => d.value === selectedDate)?.label}
                          </p>
                        </div>
                        <div>
                          <p className="text-white/40 text-sm mb-1">Time</p>
                          <p className="text-white font-medium text-lg">{selectedTimeSlot}</p>
                        </div>
                        <div className="md:col-span-2">
                          <p className="text-white/40 text-sm mb-1">Contact</p>
                          <p className="text-white font-medium">{customerName}</p>
                          <p className="text-white/60 text-sm">{customerEmail} • {customerPhone}</p>
                        </div>
                      </div>

                      <div className="border-t border-white/10 pt-6">
                        <p className="text-white/40 text-sm mb-4">Selected Services</p>
                        {getSelectedServiceObjects().map(service => {
                          const icon = serviceTypeIcons[service.serviceType || 'hardware'] || '🔧';
                          return (
                            <div key={service.id} className="flex justify-between items-center py-3 border-b border-white/5 last:border-0">
                              <div className="flex items-center gap-3">
                                <span className="text-2xl">{icon}</span>
                                <div>
                                  <p className="text-white font-medium">{service.name}</p>
                                  <p className="text-white/50 text-sm">{service.serviceType || 'Service'}</p>
                                </div>
                              </div>
                              <span className="text-primary font-bold">
                                Rs. {formatPrice(service.price)}
                              </span>
                            </div>
                          );
                        })}
                        
                        <div className="flex justify-between items-center mt-6 pt-6 border-t border-white/20">
                          <span className="text-white font-bold text-xl">Total</span>
                          <span className="text-primary font-bold text-3xl">Rs. {formatPrice(calculateTotal())}</span>
                        </div>
                      </div>

                      {issueDescription && (
                        <div className="mt-6 pt-6 border-t border-white/10">
                          <p className="text-white/40 text-sm mb-1">Additional Notes</p>
                          <p className="text-white">{issueDescription}</p>
                        </div>
                      )}
                    </div>
                  </motion.div>

                  {error && (
                    <motion.div
                      variants={itemVariants}
                      className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-red-400"
                    >
                      {error}
                    </motion.div>
                  )}

                  <motion.div variants={itemVariants} className="flex justify-between">
                    <Button variant="secondary" onClick={() => setStep(3)}>
                      <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16l-4-4m0 0l4-4m-4 4h18" />
                      </svg>
                      Back
                    </Button>
                    <Button
                      variant="primary"
                      onClick={handleSubmit}
                      disabled={isLoading}
                    >
                      {isLoading ? (
                        <>
                          <svg className="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                          </svg>
                          Booking...
                        </>
                      ) : (
                        <>
                          Confirm Booking
                          <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </>
                      )}
                    </Button>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Info Section */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="grid md:grid-cols-3 gap-6"
            >
              {[
                {
                  icon: '🔧',
                  title: 'Expert Technicians',
                  description: 'Certified professionals with years of experience',
                },
                {
                  icon: '⚡',
                  title: 'Fast Turnaround',
                  description: 'Most repairs completed within 24-48 hours',
                },
                {
                  icon: '✅',
                  title: '90-Day Warranty',
                  description: 'All repairs covered by our service warranty',
                },
              ].map((item, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ y: -5 }}
                  className="bg-dark-200/50 rounded-xl p-6 border border-white/5 text-center"
                >
                  <span className="text-4xl mb-4 block">{item.icon}</span>
                  <h4 className="text-white font-semibold mb-2">{item.title}</h4>
                  <p className="text-white/50 text-sm">{item.description}</p>
                </motion.div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default RepairBooking;
