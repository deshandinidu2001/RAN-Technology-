import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useAdminStore } from '../store/adminStore';
import { useOrdersStore, RepairBooking, Order } from '../store/ordersStore';
import { useProductStore } from '../store/productStore';
import { Product } from '../types';

type TabType = 'repairs' | 'orders' | 'products' | 'timeslots' | 'settings';

const repairStages = ['Received', 'Diagnosing', 'Waiting for Parts', 'Repairing', 'Ready for Pickup'];
const technicians = ['Kasun Silva', 'Nimesh Jayawardena', 'Pradeep Fernando', 'Ruwan Perera'];

const timeSlots = [
  '09:00 AM - 10:00 AM',
  '10:00 AM - 11:00 AM',
  '11:00 AM - 12:00 PM',
  '12:00 PM - 01:00 PM',
  '02:00 PM - 03:00 PM',
  '03:00 PM - 04:00 PM',
  '04:00 PM - 05:00 PM',
  '05:00 PM - 06:00 PM',
];

const AdminDashboard: React.FC = () => {
  const navigate = useNavigate();
  const { isAdminAuthenticated, adminLogout, blockTimeSlot, unblockTimeSlot, getBlockedSlotsForDate } = useAdminStore();
  const { 
    bookings, orders, 
    updateBookingStage, updateBookingTechnician, updateBookingEstCompletion, updateBookingCost,
    deleteBooking, updateOrderStatus, deleteOrder 
  } = useOrdersStore();
  const { products, addProduct, updateProduct, deleteProduct } = useProductStore();

  const [activeTab, setActiveTab] = useState<TabType>('repairs');
  const [selectedRepair, setSelectedRepair] = useState<RepairBooking | null>(null);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState('');

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAdminAuthenticated) {
      navigate('/admin');
    }
  }, [isAdminAuthenticated, navigate]);

  const handleLogout = () => {
    adminLogout();
    navigate('/admin');
  };

  // Filter repairs based on search
  const filteredBookings = bookings.filter(b => 
    b.ticketId.includes(searchTerm) ||
    b.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    b.customerPhone.includes(searchTerm) ||
    b.deviceType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter orders based on search
  const filteredOrders = orders.filter(o =>
    o.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
    o.customerName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    o.customerPhone.includes(searchTerm)
  );

  const blockedSlots = getBlockedSlotsForDate(selectedDate);

  // Filter products based on search
  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.category.toLowerCase().includes(searchTerm.toLowerCase()) ||
    p.brand?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Stats
  const stats = {
    totalRepairs: bookings.length,
    pendingRepairs: bookings.filter(b => b.currentStage < 4).length,
    completedRepairs: bookings.filter(b => b.currentStage === 4).length,
    totalOrders: orders.length,
    processingOrders: orders.filter(o => o.status === 'processing').length,
    totalProducts: products.length,
    lowStockProducts: products.filter(p => p.stock < 10).length,
  };

  if (!isAdminAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen bg-dark">
      {/* Header */}
      <header className="bg-dark-100/80 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-red-500/20 rounded-lg flex items-center justify-center">
              <svg className="w-6 h-6 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">RAN Admin Panel</h1>
              <p className="text-white/50 text-sm">Manage repairs, orders & settings</p>
            </div>
          </div>
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors flex items-center gap-2"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
            </svg>
            Logout
          </button>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-7 gap-4 mb-6">
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Total Repairs</p>
            <p className="text-2xl font-bold text-white">{stats.totalRepairs}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Pending</p>
            <p className="text-2xl font-bold text-amber-400">{stats.pendingRepairs}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Completed</p>
            <p className="text-2xl font-bold text-green-400">{stats.completedRepairs}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Total Orders</p>
            <p className="text-2xl font-bold text-white">{stats.totalOrders}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Processing</p>
            <p className="text-2xl font-bold text-blue-400">{stats.processingOrders}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Products</p>
            <p className="text-2xl font-bold text-purple-400">{stats.totalProducts}</p>
          </div>
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-4">
            <p className="text-white/50 text-sm">Low Stock</p>
            <p className="text-2xl font-bold text-red-400">{stats.lowStockProducts}</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {[
            { id: 'repairs', label: 'Repairs', icon: '🔧' },
            { id: 'orders', label: 'Orders', icon: '📦' },
            { id: 'products', label: 'Products', icon: '🛒' },
            { id: 'timeslots', label: 'Time Slots', icon: '🕐' },
            { id: 'settings', label: 'Settings', icon: '⚙️' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`px-4 py-2 rounded-lg font-medium flex items-center gap-2 whitespace-nowrap transition-colors ${
                activeTab === tab.id
                  ? 'bg-primary text-dark'
                  : 'bg-dark-100/50 text-white/70 hover:text-white'
              }`}
            >
              <span>{tab.icon}</span>
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search */}
        {(activeTab === 'repairs' || activeTab === 'orders' || activeTab === 'products') && (
          <div className="mb-6">
            <div className="relative">
              <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder={`Search ${activeTab}...`}
                className="w-full pl-12 pr-4 py-3 bg-dark-100/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
              />
            </div>
          </div>
        )}

        {/* Repairs Tab */}
        {activeTab === 'repairs' && (
          <div className="space-y-4">
            {filteredBookings.length === 0 ? (
              <div className="text-center py-12 text-white/50">
                No repairs found
              </div>
            ) : (
              filteredBookings.map((repair) => (
                <motion.div
                  key={repair.ticketId}
                  layout
                  className="bg-dark-100/50 border border-white/10 rounded-xl p-4 hover:border-primary/30 transition-colors"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-primary font-bold">#{repair.ticketId}</span>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          repair.currentStage === 4 ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'
                        }`}>
                          {repairStages[repair.currentStage]}
                        </span>
                      </div>
                      <p className="text-white font-medium">{repair.deviceType} - {repair.deviceModel}</p>
                      <p className="text-white/50 text-sm">{repair.customerName} • {repair.customerPhone}</p>
                      <p className="text-white/40 text-xs mt-1">Booked: {repair.bookedDate} | Est: {repair.estimatedCompletion}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedRepair(repair)}
                        className="px-3 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors text-sm"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Delete this repair?')) deleteBooking(repair.ticketId);
                        }}
                        className="px-3 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  {/* Quick Stage Update */}
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <p className="text-white/50 text-xs mb-2">Update Stage:</p>
                    <div className="flex flex-wrap gap-2">
                      {repairStages.map((stage, idx) => (
                        <button
                          key={idx}
                          onClick={() => updateBookingStage(repair.ticketId, idx)}
                          className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                            repair.currentStage === idx
                              ? 'bg-primary text-dark font-medium'
                              : 'bg-dark-200/50 text-white/60 hover:text-white'
                          }`}
                        >
                          {stage}
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}

        {/* Orders Tab */}
        {activeTab === 'orders' && (
          <div className="space-y-4">
            {filteredOrders.length === 0 ? (
              <div className="text-center py-12 text-white/50">
                No orders found
              </div>
            ) : (
              filteredOrders.map((order) => (
                <motion.div
                  key={order.id}
                  layout
                  className="bg-dark-100/50 border border-white/10 rounded-xl p-4 hover:border-primary/30 transition-colors"
                >
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-blue-400 font-bold">{order.id}</span>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          order.status === 'delivered' ? 'bg-green-500/20 text-green-400' :
                          order.status === 'shipped' ? 'bg-blue-500/20 text-blue-400' :
                          order.status === 'cancelled' ? 'bg-red-500/20 text-red-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {order.status.charAt(0).toUpperCase() + order.status.slice(1)}
                        </span>
                      </div>
                      <p className="text-white font-medium">{order.items.length} item(s) • Rs. {order.total.toLocaleString()}</p>
                      <p className="text-white/50 text-sm">{order.customerName} • {order.customerPhone}</p>
                      <p className="text-white/40 text-xs mt-1">Date: {order.date}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setSelectedOrder(order)}
                        className="px-3 py-2 bg-primary/10 text-primary rounded-lg hover:bg-primary/20 transition-colors text-sm"
                      >
                        View
                      </button>
                      <button
                        onClick={() => {
                          if (confirm('Delete this order?')) deleteOrder(order.id);
                        }}
                        className="px-3 py-2 bg-red-500/10 text-red-400 rounded-lg hover:bg-red-500/20 transition-colors text-sm"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                  {/* Quick Status Update */}
                  <div className="mt-4 pt-4 border-t border-white/10">
                    <p className="text-white/50 text-xs mb-2">Update Status:</p>
                    <div className="flex flex-wrap gap-2">
                      {(['processing', 'shipped', 'delivered', 'cancelled'] as const).map((status) => (
                        <button
                          key={status}
                          onClick={() => updateOrderStatus(order.id, status)}
                          className={`px-3 py-1.5 rounded-lg text-xs transition-colors ${
                            order.status === status
                              ? 'bg-primary text-dark font-medium'
                              : 'bg-dark-200/50 text-white/60 hover:text-white'
                          }`}
                        >
                          {status.charAt(0).toUpperCase() + status.slice(1)}
                        </button>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        )}

        {/* Products Tab */}
        {activeTab === 'products' && (
          <div>
            {/* Add Product Button */}
            <div className="mb-6 flex justify-between items-center">
              <h2 className="text-white text-xl font-bold">{filteredProducts.length} Products</h2>
              <button
                onClick={() => {
                  setSelectedProduct(null);
                  setShowProductForm(true);
                }}
                className="px-6 py-3 bg-primary text-dark rounded-xl font-semibold hover:bg-primary/90 transition-colors flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Add Product
              </button>
            </div>

            {/* Products Grid */}
            {filteredProducts.length === 0 ? (
              <div className="text-center py-12 text-white/50">
                No products found
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredProducts.map((product) => (
                  <motion.div
                    key={product.id}
                    layout
                    className="bg-dark-100/50 border border-white/10 rounded-xl p-4 hover:border-primary/30 transition-colors"
                  >
                    {/* Product Image */}
                    {product.image && (
                      <div className="aspect-square rounded-lg overflow-hidden mb-3 bg-dark-200/50">
                        <img 
                          src={product.image} 
                          alt={product.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    {/* Product Info */}
                    <div className="space-y-2">
                      <div className="flex items-start justify-between gap-2">
                        <h3 className="text-white font-semibold line-clamp-2">{product.name}</h3>
                        <span className={`text-xs px-2 py-1 rounded-full shrink-0 ${
                          product.stock > 10 
                            ? 'bg-green-500/20 text-green-400' 
                            : product.stock > 0 
                            ? 'bg-amber-500/20 text-amber-400'
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {product.stock > 0 ? `${product.stock} in stock` : 'Out of stock'}
                        </span>
                      </div>
                      
                      <p className="text-white/50 text-sm line-clamp-2">{product.description}</p>
                      
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs px-2 py-1 bg-primary/20 text-primary rounded-full">
                          {product.category}
                        </span>
                        {product.brand && (
                          <span className="text-xs px-2 py-1 bg-white/10 text-white/70 rounded-full">
                            {product.brand}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-2">
                        <p className="text-primary text-xl font-bold">
                          Rs. {product.price.toLocaleString()}
                        </p>
                        <div className="flex gap-2">
                          <button
                            onClick={() => {
                              setSelectedProduct(product);
                              setShowProductForm(true);
                            }}
                            className="p-2 bg-blue-500/20 text-blue-400 rounded-lg hover:bg-blue-500/30 transition-colors"
                          >
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Delete ${product.name}?`)) {
                                deleteProduct(product.id);
                              }
                            }}
                            className="p-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition-colors"
                          >
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                            </svg>
                          </button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Time Slots Tab */}
        {activeTab === 'timeslots' && (
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-6">
            <div className="mb-6">
              <label className="block text-white/70 text-sm mb-2">Select Date</label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
              />
            </div>

            <div>
              <h3 className="text-white font-semibold mb-4">Time Slots for {selectedDate}</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                {timeSlots.map((slot) => {
                  const isBlocked = blockedSlots.includes(slot);
                  return (
                    <button
                      key={slot}
                      onClick={() => {
                        if (isBlocked) {
                          unblockTimeSlot(selectedDate, slot);
                        } else {
                          blockTimeSlot(selectedDate, slot);
                        }
                      }}
                      className={`p-4 rounded-xl border transition-all ${
                        isBlocked
                          ? 'bg-red-500/20 border-red-500/50 text-red-400'
                          : 'bg-green-500/10 border-green-500/30 text-green-400 hover:bg-green-500/20'
                      }`}
                    >
                      <p className="font-medium">{slot}</p>
                      <p className="text-xs mt-1 opacity-70">
                        {isBlocked ? '🚫 Blocked' : '✅ Available'}
                      </p>
                    </button>
                  );
                })}
              </div>
              <p className="text-white/40 text-sm mt-4">
                Click a slot to toggle availability. Blocked slots won't be available for booking.
              </p>
            </div>
          </div>
        )}

        {/* Settings Tab */}
        {activeTab === 'settings' && (
          <div className="bg-dark-100/50 border border-white/10 rounded-xl p-6 space-y-6">
            <div>
              <h3 className="text-white font-semibold mb-4">Data Management</h3>
              <div className="space-y-3">
                <button
                  onClick={() => {
                    if (confirm('Clear all repairs? This cannot be undone.')) {
                      useOrdersStore.getState().bookings.forEach(b => deleteBooking(b.ticketId));
                    }
                  }}
                  className="w-full sm:w-auto px-4 py-3 bg-red-500/10 text-red-400 border border-red-500/30 rounded-xl hover:bg-red-500/20 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  Clear All Repairs
                </button>
                <button
                  onClick={() => {
                    if (confirm('Clear all orders? This cannot be undone.')) {
                      useOrdersStore.getState().orders.forEach(o => deleteOrder(o.id));
                    }
                  }}
                  className="w-full sm:w-auto px-4 py-3 bg-red-500/10 text-red-400 border border-red-500/30 rounded-xl hover:bg-red-500/20 transition-colors flex items-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                  Clear All Orders
                </button>
              </div>
            </div>

            <div>
              <h3 className="text-white font-semibold mb-4">Admin Info</h3>
              <div className="bg-dark-200/50 rounded-xl p-4">
                <p className="text-white/70 text-sm">Admin password can be changed in the code.</p>
                <p className="text-white/50 text-xs mt-2">Current file: src/store/adminStore.ts</p>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Repair Edit Modal */}
      <AnimatePresence>
        {selectedRepair && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedRepair(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-dark-100 border border-white/10 rounded-2xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Edit Repair #{selectedRepair.ticketId}</h2>
                <button
                  onClick={() => setSelectedRepair(null)}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-2">Stage</label>
                  <select
                    value={selectedRepair.currentStage}
                    onChange={(e) => {
                      updateBookingStage(selectedRepair.ticketId, Number(e.target.value));
                      setSelectedRepair({ ...selectedRepair, currentStage: Number(e.target.value) });
                    }}
                    className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                  >
                    {repairStages.map((stage, idx) => (
                      <option key={idx} value={idx}>{stage}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">Technician</label>
                  <select
                    value={selectedRepair.technicianName}
                    onChange={(e) => {
                      updateBookingTechnician(selectedRepair.ticketId, e.target.value);
                      setSelectedRepair({ ...selectedRepair, technicianName: e.target.value });
                    }}
                    className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                  >
                    {technicians.map((tech) => (
                      <option key={tech} value={tech}>{tech}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">Estimated Completion</label>
                  <input
                    type="date"
                    value={selectedRepair.estimatedCompletion}
                    onChange={(e) => {
                      updateBookingEstCompletion(selectedRepair.ticketId, e.target.value);
                      setSelectedRepair({ ...selectedRepair, estimatedCompletion: e.target.value });
                    }}
                    className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                  />
                </div>

                <div>
                  <label className="block text-white/70 text-sm mb-2">Total Cost (Rs.)</label>
                  <input
                    type="number"
                    value={selectedRepair.totalCost}
                    onChange={(e) => {
                      const cost = Number(e.target.value);
                      updateBookingCost(selectedRepair.ticketId, cost);
                      setSelectedRepair({ ...selectedRepair, totalCost: cost });
                    }}
                    className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                  />
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white/70 text-sm mb-2">Customer Info</h4>
                  <p className="text-white">{selectedRepair.customerName}</p>
                  <p className="text-white/60 text-sm">{selectedRepair.customerEmail}</p>
                  <p className="text-white/60 text-sm">{selectedRepair.customerPhone}</p>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white/70 text-sm mb-2">Device Info</h4>
                  <p className="text-white">{selectedRepair.deviceType} - {selectedRepair.deviceModel}</p>
                  <p className="text-white/60 text-sm mt-1">{selectedRepair.issueDescription}</p>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {selectedRepair.services.map((service, idx) => (
                      <span key={idx} className="px-2 py-1 bg-primary/10 text-primary text-xs rounded-full">
                        {service}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => setSelectedRepair(null)}
                  className="flex-1 py-3 bg-primary text-dark font-semibold rounded-xl hover:bg-primary/90 transition-colors"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Order View Modal */}
      <AnimatePresence>
        {selectedOrder && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedOrder(null)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-dark-100 border border-white/10 rounded-2xl p-6 w-full max-w-lg max-h-[90vh] overflow-y-auto"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-white">Order {selectedOrder.id}</h2>
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="w-8 h-8 rounded-full bg-white/10 flex items-center justify-center text-white/70 hover:text-white"
                >
                  ✕
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-white/70 text-sm mb-2">Status</label>
                  <select
                    value={selectedOrder.status}
                    onChange={(e) => {
                      const status = e.target.value as Order['status'];
                      updateOrderStatus(selectedOrder.id, status);
                      setSelectedOrder({ ...selectedOrder, status });
                    }}
                    className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                  >
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white/70 text-sm mb-2">Customer Info</h4>
                  <p className="text-white">{selectedOrder.customerName}</p>
                  <p className="text-white/60 text-sm">{selectedOrder.customerEmail}</p>
                  <p className="text-white/60 text-sm">{selectedOrder.customerPhone}</p>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white/70 text-sm mb-2">Shipping Address</h4>
                  <p className="text-white/80 text-sm">{selectedOrder.shippingAddress}</p>
                </div>

                <div className="pt-4 border-t border-white/10">
                  <h4 className="text-white/70 text-sm mb-2">Items</h4>
                  <div className="space-y-2">
                    {selectedOrder.items.map((item, idx) => (
                      <div key={idx} className="flex items-center gap-3 p-2 bg-dark-200/30 rounded-lg">
                        <img src={item.image} alt={item.name} className="w-12 h-12 object-cover rounded-lg bg-dark-200" />
                        <div className="flex-1">
                          <p className="text-white text-sm">{item.name}</p>
                          <p className="text-white/50 text-xs">Qty: {item.quantity}</p>
                        </div>
                        <p className="text-primary font-medium">Rs. {(item.price * item.quantity).toLocaleString()}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-white/10 flex justify-between items-center">
                  <span className="text-white font-semibold">Total</span>
                  <span className="text-primary text-xl font-bold">Rs. {selectedOrder.total.toLocaleString()}</span>
                </div>
              </div>

              <div className="mt-6 flex gap-3">
                <button
                  onClick={() => setSelectedOrder(null)}
                  className="flex-1 py-3 bg-primary text-dark font-semibold rounded-xl hover:bg-primary/90 transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Product Form Modal */}
      <AnimatePresence>
        {showProductForm && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
            onClick={() => setShowProductForm(false)}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-dark-100 border border-white/10 rounded-2xl p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto"
            >
              <h2 className="text-white text-2xl font-bold mb-6">
                {selectedProduct ? 'Edit Product' : 'Add New Product'}
              </h2>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  const formData = new FormData(e.currentTarget);
                  
                  const productData = {
                    name: formData.get('name') as string,
                    description: formData.get('description') as string,
                    price: Number(formData.get('price')),
                    image: formData.get('image') as string,
                    category: formData.get('category') as string,
                    subcategory: formData.get('subcategory') as string || undefined,
                    stock: Number(formData.get('stock')),
                    featured: formData.get('featured') === 'on',
                    brand: formData.get('brand') as string || undefined,
                    sku: formData.get('sku') as string || undefined,
                  };

                  if (selectedProduct) {
                    updateProduct(selectedProduct.id, productData);
                  } else {
                    addProduct(productData);
                  }
                  
                  setShowProductForm(false);
                  setSelectedProduct(null);
                }}
                className="space-y-4"
              >
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-white/70 text-sm mb-2">Product Name *</label>
                    <input
                      type="text"
                      name="name"
                      defaultValue={selectedProduct?.name}
                      required
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="e.g., iPhone 15 Pro Max"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-white/70 text-sm mb-2">Description *</label>
                    <textarea
                      name="description"
                      defaultValue={selectedProduct?.description}
                      required
                      rows={3}
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50 resize-none"
                      placeholder="Product description..."
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Price (Rs.) *</label>
                    <input
                      type="number"
                      name="price"
                      defaultValue={selectedProduct?.price}
                      required
                      min="0"
                      step="0.01"
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="0.00"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Stock *</label>
                    <input
                      type="number"
                      name="stock"
                      defaultValue={selectedProduct?.stock}
                      required
                      min="0"
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="0"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Category *</label>
                    <select
                      name="category"
                      defaultValue={selectedProduct?.category}
                      required
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white focus:outline-none focus:border-primary/50"
                    >
                      <option value="">Select Category</option>
                      <option value="laptops">Laptops</option>
                      <option value="smartphones">Smartphones</option>
                      <option value="laptop-accessories">Laptop Accessories</option>
                      <option value="graphics-cards">Graphics Cards</option>
                      <option value="accessories">Accessories</option>
                      <option value="monitors">Monitors</option>
                      <option value="storage">Storage</option>
                      <option value="gaming">Gaming</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Subcategory</label>
                    <input
                      type="text"
                      name="subcategory"
                      defaultValue={selectedProduct?.subcategory}
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="e.g., RAM, SSD"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">Brand</label>
                    <input
                      type="text"
                      name="brand"
                      defaultValue={selectedProduct?.brand}
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="e.g., Apple, Samsung"
                    />
                  </div>

                  <div>
                    <label className="block text-white/70 text-sm mb-2">SKU</label>
                    <input
                      type="text"
                      name="sku"
                      defaultValue={selectedProduct?.sku}
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="e.g., IPH-15-PM-256"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-white/70 text-sm mb-2">Image URL *</label>
                    <input
                      type="url"
                      name="image"
                      defaultValue={selectedProduct?.image}
                      required
                      className="w-full px-4 py-3 bg-dark-200/50 border border-white/10 rounded-xl text-white placeholder:text-white/40 focus:outline-none focus:border-primary/50"
                      placeholder="https://example.com/image.jpg"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="flex items-center gap-2 text-white cursor-pointer">
                      <input
                        type="checkbox"
                        name="featured"
                        defaultChecked={selectedProduct?.featured}
                        className="w-5 h-5 rounded border-white/10 bg-dark-200/50 text-primary focus:ring-primary focus:ring-offset-0"
                      />
                      <span>Mark as Featured Product</span>
                    </label>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowProductForm(false);
                      setSelectedProduct(null);
                    }}
                    className="flex-1 py-3 bg-dark-200/50 text-white font-semibold rounded-xl hover:bg-dark-200 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 py-3 bg-primary text-dark font-semibold rounded-xl hover:bg-primary/90 transition-colors"
                  >
                    {selectedProduct ? 'Update Product' : 'Add Product'}
                  </button>
                </div>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default AdminDashboard;
