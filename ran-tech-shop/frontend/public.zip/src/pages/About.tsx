import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { RevealOnScroll, StaggerContainer } from '../components/home/ScrollSection';
import Button from '../components/ui/Button';

const About: React.FC = () => {
  const milestones = [
    { year: '2020', title: 'Founded', description: 'RAN was born from a passion for technology' },
    { year: '2021', title: '1K Customers', description: 'Reached our first thousand happy customers' },
    { year: '2022', title: 'Expanded', description: 'Grew our product catalog to 500+ items' },
    { year: '2023', title: 'Global Reach', description: 'Started shipping to 50+ countries' },
    { year: '2024', title: '10K+ Products Sold', description: 'Milestone of 10,000 products delivered' },
  ];

  return (
    <div className="relative min-h-screen pt-24 pb-16 bg-gradient-to-b from-dark via-dark/95 to-dark text-white overflow-hidden">
      <div className="pointer-events-none absolute inset-0 opacity-70" style={{
        background:
          'radial-gradient(circle at 20% 20%, rgba(247,181,0,0.08), transparent 32%),' +
          'radial-gradient(circle at 80% 10%, rgba(6,182,212,0.08), transparent 30%),' +
          'radial-gradient(circle at 70% 80%, rgba(124,58,237,0.08), transparent 30%)'
      }} />
      {/* Hero Section */}
      <section className="relative overflow-hidden py-24">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_20%_20%,rgba(247,181,0,0.14),transparent_35%),radial-gradient(circle_at_80%_0%,rgba(255,107,53,0.12),transparent_35%),radial-gradient(circle_at_70%_80%,rgba(124,58,237,0.12),transparent_30%)]" />
        <div className="absolute inset-0 bg-gradient-to-b from-dark via-dark/90 to-dark" />

        <div className="relative z-10 container mx-auto px-4">
          <div className="max-w-4xl">
            <motion.span
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-primary text-sm font-semibold bg-primary/10 border border-primary/20"
            >
              Who We Are
              <span className="w-2 h-2 rounded-full bg-primary" />
            </motion.span>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1, duration: 0.8 }}
              className="mt-6 space-y-3"
            >
              <p className="text-white/50 uppercase tracking-[0.3em] text-xs">RAN / About</p>
              <h1 className="text-4xl md:text-6xl font-black leading-tight">
                <motion.span
                  className="block text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-accent"
                  initial={{ backgroundPosition: '0% 50%' }}
                  animate={{ backgroundPosition: '100% 50%' }}
                  transition={{ repeat: Infinity, repeatType: 'reverse', duration: 6, ease: 'linear' }}
                  style={{ backgroundSize: '200% 200%' }}
                >
                  About Our Story
                </motion.span>
                <span className="block text-white/80 mt-2">Premium tech for everyone</span>
              </h1>
            </motion.div>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2, duration: 0.8 }}
              className="text-white/70 text-lg leading-relaxed mt-6 max-w-2xl"
            >
              We're on a mission to make premium technology accessible to everyone. Founded by tech enthusiasts, for tech enthusiasts.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.8 }}
              className="mt-10 flex flex-wrap gap-4"
            >
              {["Premium hardware", "Global shipping", "Expert curation"].map((pill) => (
                <span
                  key={pill}
                  className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-white/80 backdrop-blur"
                >
                  {pill}
                </span>
              ))}
            </motion.div>

            <motion.div
              initial={{ scaleX: 0 }}
              animate={{ scaleX: 1 }}
              transition={{ delay: 0.35, duration: 0.8, ease: 'easeOut' }}
              className="mt-10 h-[2px] w-full bg-gradient-to-r from-primary via-secondary to-accent origin-left"
            />
          </div>
        </div>
      </section>

      {/* Mission Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <RevealOnScroll>
              <div className="relative">
                <div className="aspect-square rounded-3xl overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&h=800&fit=crop"
                    alt="Technology"
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-primary/20 rounded-3xl -z-10" />
                <div className="absolute -top-8 -left-8 w-32 h-32 bg-primary/10 rounded-2xl -z-10" />
              </div>
            </RevealOnScroll>

            <RevealOnScroll>
              <div>
                <h2 className="text-4xl font-bold text-white mb-6">Our Mission</h2>
                <p className="text-white/60 text-lg leading-relaxed mb-6">
                  At RAN, we believe that everyone deserves access to high-quality technology.
                  We curate the best products from leading manufacturers and deliver them
                  directly to your doorstep.
                </p>
                <p className="text-white/60 text-lg leading-relaxed mb-8">
                  Our commitment to excellence means we only stock products that meet our
                  rigorous quality standards. From graphics cards to smartphones, every
                  item in our catalog has been carefully selected.
                </p>
                <div className="flex gap-8">
                  <div>
                    <div className="text-4xl font-bold text-primary">10K+</div>
                    <div className="text-white/60">Products Sold</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-primary">50+</div>
                    <div className="text-white/60">Countries</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-primary">99%</div>
                    <div className="text-white/60">Satisfaction</div>
                  </div>
                </div>
              </div>
            </RevealOnScroll>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="py-20 bg-dark-100/30">
        <div className="container mx-auto px-4">
          <RevealOnScroll>
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">Our Values</h2>
              <p className="text-white/60 max-w-2xl mx-auto">
                The principles that guide everything we do
              </p>
            </div>
          </RevealOnScroll>

          <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                icon: '🎯',
                title: 'Quality First',
                description: 'We never compromise on product quality',
              },
              {
                icon: '🤝',
                title: 'Customer Focus',
                description: 'Your satisfaction is our top priority',
              },
              {
                icon: '💡',
                title: 'Innovation',
                description: 'Always seeking the latest and greatest',
              },
              {
                icon: '🌍',
                title: 'Sustainability',
                description: 'Committed to eco-friendly practices',
              },
            ].map((value, index) => (
              <RevealOnScroll key={index}>
                <motion.div
                  whileHover={{ y: -5 }}
                  className="bg-dark-200/50 backdrop-blur-sm border border-white/5 rounded-2xl p-8 text-center"
                >
                  <div className="text-5xl mb-4">{value.icon}</div>
                  <h3 className="text-xl font-bold text-white mb-3">{value.title}</h3>
                  <p className="text-white/60">{value.description}</p>
                </motion.div>
              </RevealOnScroll>
            ))}
          </StaggerContainer>
        </div>
      </section>

      {/* Timeline Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <RevealOnScroll>
            <div className="text-center mb-16">
              <h2 className="text-4xl font-bold text-white mb-4">Our Journey</h2>
              <p className="text-white/60 max-w-2xl mx-auto">
                From a small startup to a global tech destination
              </p>
            </div>
          </RevealOnScroll>

          <div className="relative max-w-4xl mx-auto">
            {/* Timeline line */}
            <div className="absolute left-1/2 top-0 bottom-0 w-px bg-white/10 -translate-x-1/2" />

            {milestones.map((milestone, index) => (
              <RevealOnScroll key={index}>
                <motion.div
                  initial={{ opacity: 0, x: index % 2 === 0 ? -50 : 50 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className={`relative flex items-center mb-12 ${
                    index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                  }`}
                >
                  <div className={`w-1/2 ${index % 2 === 0 ? 'pr-12 text-right' : 'pl-12'}`}>
                    <div className="text-primary font-bold text-2xl mb-2">
                      {milestone.year}
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{milestone.title}</h3>
                    <p className="text-white/60">{milestone.description}</p>
                  </div>
                  <div className="absolute left-1/2 -translate-x-1/2 w-4 h-4 bg-primary rounded-full border-4 border-dark" />
                </motion.div>
              </RevealOnScroll>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <RevealOnScroll>
            <div className="bg-gradient-to-r from-primary/20 to-primary/5 rounded-3xl p-12 text-center">
              <h2 className="text-4xl font-bold text-white mb-4">
                Ready to experience the RAN difference?
              </h2>
              <p className="text-white/60 mb-8 max-w-2xl mx-auto">
                Browse our collection of premium tech products and join thousands of satisfied customers.
              </p>
              <Link to="/shop">
                <Button variant="primary" size="lg">
                  Start Shopping
                  <svg className="w-5 h-5 ml-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                  </svg>
                </Button>
              </Link>
            </div>
          </RevealOnScroll>
        </div>
      </section>
    </div>
  );
};

export default About;
