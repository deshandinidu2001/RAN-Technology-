import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useSearchParams } from 'react-router-dom';
import ProductGrid from '../components/shop/ProductGrid';
import FilterSidebar from '../components/shop/FilterSidebar';
import ProductModal from '../components/shop/ProductModal';
import { Product } from '../types';
import api from '../utils/api';
import { useProductStore } from '../store/productStore';

interface ProductFilters {
  brands: string[];
  ramTypes: string[];
  ramSpeeds: number[];
  ramCapacities: number[];
  ssdTypes: string[];
  ssdCapacities: number[];
  compatibleLaptops: string[];
}

const PRODUCTS_PER_PAGE = 12;

const Shop: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filters, setFilters] = useState<ProductFilters | null>(null);
  
  // Pagination
  const [currentPage, setCurrentPage] = useState(1);

  // Filter states
  const [selectedCategory, setSelectedCategory] = useState<string | null>(
    searchParams.get('category')
  );
  const [selectedSubcategory, setSelectedSubcategory] = useState<string | null>(
    searchParams.get('subcategory')
  );
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500000]);
  const [sortBy, setSortBy] = useState('featured');
  const [searchQuery, setSearchQuery] = useState(searchParams.get('search') || '');

  // Advanced filters for accessories
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);
  const [selectedRamType, setSelectedRamType] = useState<string | null>(null);
  const [selectedRamSpeed, setSelectedRamSpeed] = useState<number | null>(null);
  const [selectedRamCapacity, setSelectedRamCapacity] = useState<number | null>(null);
  const [selectedSsdType, setSelectedSsdType] = useState<string | null>(null);
  const [selectedSsdCapacity, setSelectedSsdCapacity] = useState<number | null>(null);
  const [selectedCompatibility, setSelectedCompatibility] = useState<string | null>(null);

  // Get local products from store (admin-added products)
  const { products: localProducts } = useProductStore();

  // Fetch products
  useEffect(() => {
    const fetchProducts = async () => {
      setIsLoading(true);
      try {
        const params = new URLSearchParams();
        params.set('limit', '100');
        params.set('isService', 'false');
        
        if (selectedCategory) params.set('category', selectedCategory);
        if (selectedSubcategory) params.set('subcategory', selectedSubcategory);
        if (selectedBrand) params.set('brand', selectedBrand);
        if (selectedRamType) params.set('ramType', selectedRamType);
        if (selectedRamSpeed) params.set('ramSpeed', selectedRamSpeed.toString());
        if (selectedRamCapacity) params.set('ramCapacity', selectedRamCapacity.toString());
        if (selectedSsdType) params.set('ssdType', selectedSsdType);
        if (selectedSsdCapacity) params.set('ssdCapacity', selectedSsdCapacity.toString());
        if (selectedCompatibility) params.set('compatibility', selectedCompatibility);
        if (searchQuery) params.set('search', searchQuery);

        const response = await api.get(`/products?${params.toString()}`);
        const apiProducts = response.data.products || response.data || [];
        
        // Merge API products with local products (admin-added)
        // Filter local products based on current filters
        let filteredLocalProducts = localProducts;
        if (selectedCategory) {
          filteredLocalProducts = filteredLocalProducts.filter(p => 
            p.category?.toLowerCase() === selectedCategory.toLowerCase()
          );
        }
        if (selectedSubcategory) {
          filteredLocalProducts = filteredLocalProducts.filter(p => 
            p.subcategory?.toLowerCase() === selectedSubcategory.toLowerCase()
          );
        }
        if (selectedBrand) {
          filteredLocalProducts = filteredLocalProducts.filter(p => 
            p.brand?.toLowerCase() === selectedBrand.toLowerCase()
          );
        }
        if (searchQuery) {
          const query = searchQuery.toLowerCase();
          filteredLocalProducts = filteredLocalProducts.filter(p => 
            p.name.toLowerCase().includes(query) || 
            p.description.toLowerCase().includes(query)
          );
        }
        
        // Combine and remove duplicates by ID
        const allProducts = [...filteredLocalProducts, ...apiProducts];
        const uniqueProducts = allProducts.filter((product, index, self) =>
          index === self.findIndex(p => p.id === product.id)
        );
        
        setProducts(uniqueProducts);
      } catch (error) {
        console.error('Failed to fetch products:', error);
        // If API fails, still show local products
        setProducts(localProducts);
      } finally {
        setIsLoading(false);
      }
    };

    fetchProducts();
  }, [selectedCategory, selectedSubcategory, selectedBrand, selectedRamType, selectedRamSpeed, selectedRamCapacity, selectedSsdType, selectedSsdCapacity, selectedCompatibility, searchQuery, localProducts]);

  // Fetch filters for laptop accessories
  useEffect(() => {
    const fetchFilters = async () => {
      try {
        const params = new URLSearchParams();
        if (selectedCategory) params.set('category', selectedCategory);
        if (selectedSubcategory) params.set('subcategory', selectedSubcategory);
        
        const response = await api.get(`/products/filters?${params.toString()}`);
        setFilters(response.data);
      } catch (error) {
        console.error('Failed to fetch filters:', error);
      }
    };

    fetchFilters();
  }, [selectedCategory, selectedSubcategory]);

  // Apply filters
  useEffect(() => {
    let result = [...products];

    // Category filter
    if (selectedCategory) {
      result = result.filter((p) => p.category === selectedCategory);
    }

    // Price filter
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(query) ||
          p.description.toLowerCase().includes(query)
      );
    }

    // Sorting
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'name':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'newest':
        result.sort(
          (a, b) =>
            new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        break;
      case 'featured':
      default:
        result.sort((a, b) => (b.featured ? 1 : 0) - (a.featured ? 1 : 0));
    }

    setFilteredProducts(result);
    setCurrentPage(1); // Reset to first page when filters change
  }, [products, selectedCategory, priceRange, sortBy, searchQuery]);

  // Update URL params
  useEffect(() => {
    const params = new URLSearchParams();
    if (selectedCategory) params.set('category', selectedCategory);
    if (searchQuery) params.set('search', searchQuery);
    setSearchParams(params, { replace: true });
  }, [selectedCategory, searchQuery, setSearchParams]);

  // Sync search from URL on initial load
  useEffect(() => {
    const urlSearch = searchParams.get('search');
    if (urlSearch && urlSearch !== searchQuery) {
      setSearchQuery(urlSearch);
    }
  }, []);

  const handleQuickView = (product: Product) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  const resetAdvancedFilters = () => {
    setSelectedBrand(null);
    setSelectedRamType(null);
    setSelectedRamSpeed(null);
    setSelectedRamCapacity(null);
    setSelectedSsdType(null);
    setSelectedSsdCapacity(null);
    setSelectedCompatibility(null);
  };

  const handleCategoryChange = (cat: string | null) => {
    setSelectedCategory(cat);
    setSelectedSubcategory(null);
    resetAdvancedFilters();
  };

  const handleSubcategoryChange = (sub: string | null) => {
    setSelectedSubcategory(sub);
    resetAdvancedFilters();
  };

  const categories = [
    { slug: 'laptop-accessories', name: 'Laptop Accessories', count: products.filter(p => p.category?.toLowerCase() === 'laptop-accessories').length },
    { slug: 'graphics-cards', name: 'Graphics Cards', count: products.filter(p => p.category?.toLowerCase() === 'graphics-cards').length },
    { slug: 'laptops', name: 'Laptops', count: products.filter(p => p.category?.toLowerCase() === 'laptops').length },
    { slug: 'smartphones', name: 'Smartphones', count: products.filter(p => p.category?.toLowerCase() === 'smartphones').length },
    { slug: 'accessories', name: 'Accessories', count: products.filter(p => p.category?.toLowerCase() === 'accessories').length },
    { slug: 'monitors', name: 'Monitors', count: products.filter(p => p.category?.toLowerCase() === 'monitors').length },
    { slug: 'storage', name: 'Storage', count: products.filter(p => p.category?.toLowerCase() === 'storage').length },
    { slug: 'gaming', name: 'Gaming', count: products.filter(p => p.category?.toLowerCase() === 'gaming').length },
  ];

  const subcategories = [
    { slug: 'ram', name: 'RAM Memory', icon: '🧠' },
    { slug: 'ssd', name: 'SSD Storage', icon: '💿' },
    { slug: 'cooling-pad', name: 'Cooling Pads', icon: '❄️' },
    { slug: 'gpu', name: 'External GPUs', icon: '🎮' },
    { slug: 'display', name: 'Displays', icon: '🖥️' },
  ];

  // Pagination calculations
  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE);
  const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
  const endIndex = startIndex + PRODUCTS_PER_PAGE;
  const paginatedProducts = filteredProducts.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Generate page numbers to display
  const getPageNumbers = () => {
    const pages: (number | string)[] = [];
    if (totalPages <= 7) {
      for (let i = 1; i <= totalPages; i++) pages.push(i);
    } else {
      if (currentPage <= 3) {
        pages.push(1, 2, 3, 4, '...', totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1, '...', totalPages - 3, totalPages - 2, totalPages - 1, totalPages);
      } else {
        pages.push(1, '...', currentPage - 1, currentPage, currentPage + 1, '...', totalPages);
      }
    }
    return pages;
  };

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            {selectedSubcategory
              ? subcategories.find((c) => c.slug === selectedSubcategory)?.name
              : selectedCategory
              ? categories.find((c) => c.slug === selectedCategory)?.name || 'Shop'
              : 'All Products'}
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Discover our collection of premium tech accessories and gadgets
          </p>
        </motion.div>

        {/* Search bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="max-w-2xl mx-auto mb-8"
        >
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search products..."
              className="w-full px-6 py-4 pl-14 bg-dark-200 border border-white/10 rounded-2xl text-white placeholder-white/40 focus:outline-none focus:border-primary transition-colors"
            />
            <svg
              className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-white/40"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-5 top-1/2 -translate-y-1/2 text-white/40 hover:text-white transition-colors"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </motion.div>

        {/* Main content */}
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar with all filters */}
          <motion.aside
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="lg:w-80 flex-shrink-0"
          >
            <FilterSidebar
              categories={categories}
              selectedCategory={selectedCategory}
              onCategoryChange={handleCategoryChange}
              priceRange={priceRange}
              onPriceRangeChange={setPriceRange}
              sortBy={sortBy}
              onSortChange={setSortBy}
              subcategories={subcategories}
              selectedSubcategory={selectedSubcategory}
              onSubcategoryChange={handleSubcategoryChange}
              filters={filters}
              selectedBrand={selectedBrand}
              onBrandChange={setSelectedBrand}
              selectedRamType={selectedRamType}
              onRamTypeChange={setSelectedRamType}
              selectedRamSpeed={selectedRamSpeed}
              onRamSpeedChange={setSelectedRamSpeed}
              selectedRamCapacity={selectedRamCapacity}
              onRamCapacityChange={setSelectedRamCapacity}
              selectedSsdType={selectedSsdType}
              onSsdTypeChange={setSelectedSsdType}
              selectedSsdCapacity={selectedSsdCapacity}
              onSsdCapacityChange={setSelectedSsdCapacity}
              selectedCompatibility={selectedCompatibility}
              onCompatibilityChange={setSelectedCompatibility}
              onResetFilters={resetAdvancedFilters}
            />
          </motion.aside>

          {/* Products */}
          <motion.main
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="flex-1"
          >
            {/* Results count and mobile sort */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <p className="text-white/60">
                  {searchQuery && (
                    <span className="block text-sm text-primary mb-1">
                      Results for "{searchQuery}"
                    </span>
                  )}
                  Showing{' '}
                  <span className="text-white font-medium">
                    {filteredProducts.length > 0 ? startIndex + 1 : 0}-{Math.min(endIndex, filteredProducts.length)}
                  </span>{' '}
                  of{' '}
                  <span className="text-white font-medium">
                    {filteredProducts.length}
                  </span>{' '}
                  products
                </p>
              </div>

              {/* Mobile sort */}
              <div className="lg:hidden">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                  className="px-4 py-2 bg-dark-200 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                >
                  <option value="featured">Featured</option>
                  <option value="newest">Newest</option>
                  <option value="price-low">Price: Low to High</option>
                  <option value="price-high">Price: High to Low</option>
                  <option value="name">Name</option>
                </select>
              </div>
            </div>

            <ProductGrid
              products={paginatedProducts}
              isLoading={isLoading}
              onQuickView={handleQuickView}
            />

            {/* Pagination */}
            {totalPages > 1 && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex items-center justify-center gap-2 mt-12"
              >
                {/* Previous button */}
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    currentPage === 1
                      ? 'bg-dark-300 text-white/30 cursor-not-allowed'
                      : 'bg-dark-200 text-white hover:bg-dark-100 border border-white/10'
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                  </svg>
                </button>

                {/* Page numbers */}
                {getPageNumbers().map((page, index) => (
                  <button
                    key={index}
                    onClick={() => typeof page === 'number' && handlePageChange(page)}
                    disabled={page === '...'}
                    className={`w-10 h-10 rounded-lg font-medium transition-all ${
                      page === currentPage
                        ? 'bg-primary text-dark'
                        : page === '...'
                        ? 'bg-transparent text-white/50 cursor-default'
                        : 'bg-dark-200 text-white hover:bg-dark-100 border border-white/10'
                    }`}
                  >
                    {page}
                  </button>
                ))}

                {/* Next button */}
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className={`px-4 py-2 rounded-lg font-medium transition-all ${
                    currentPage === totalPages
                      ? 'bg-dark-300 text-white/30 cursor-not-allowed'
                      : 'bg-dark-200 text-white hover:bg-dark-100 border border-white/10'
                  }`}
                >
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </motion.div>
            )}
          </motion.main>
        </div>
      </div>

      {/* Quick view modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setSelectedProduct(null);
        }}
      />
    </div>
  );
};

export default Shop;
