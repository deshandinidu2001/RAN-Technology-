import React, { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import Lenis from 'lenis';

const Landing: React.FC = () => {
  const navigate = useNavigate();
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize Lenis smooth scroll
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    function raf(time: number) {
      lenis.raf(time);
      requestAnimationFrame(raf);
    }

    requestAnimationFrame(raf);

    return () => {
      lenis.destroy();
    };
  }, []);

  // Animated side cards
  const sideCardVariants = {
    hidden: { opacity: 0, x: 0, y: 0 },
    visible: (custom: { x: number; y: number; delay: number }) => ({
      opacity: 1,
      x: custom.x,
      y: custom.y,
      transition: {
        delay: custom.delay,
        duration: 1,
        ease: 'easeOut',
      },
    }),
    float: {
      y: [0, -15, 0],
      transition: {
        duration: 4,
        repeat: Infinity,
        ease: 'easeInOut',
      },
    },
  };

  return (
    <div ref={containerRef} className="min-h-screen bg-black text-white overflow-hidden">
      {/* Hero Section with Video Background */}
      <div className="relative min-h-screen flex items-center justify-center">
        {/* Video Background */}
        <video
          className="absolute inset-0 w-full h-full object-cover"
          src="/videos/landpage.mp4"
          autoPlay
          muted
          loop
          playsInline
        />

        {/* Gradient Overlays */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/85 via-black/80 to-black/90" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(247,181,0,0.12),transparent_40%),radial-gradient(circle_at_70%_60%,rgba(6,182,212,0.12),transparent_35%)]" />

        {/* Animated Side Cards - Left */}
        <motion.div
          custom={{ x: -120, y: -80, delay: 0.2 }}
          variants={sideCardVariants}
          initial="hidden"
          animate={["visible", "float"]}
          className="absolute left-6 top-24 md:left-12 md:top-1/3 text-white/70 z-10"
        >
          <div className="text-sm font-semibold mb-1">🛍️ Shop</div>
          <div className="text-xs text-white/50">Premium Tech</div>
        </motion.div>

        <motion.div
          custom={{ x: -100, y: 60, delay: 0.4 }}
          variants={sideCardVariants}
          initial="hidden"
          animate={["visible", "float"]}
          className="absolute left-4 bottom-1/3 md:left-8 text-white/70 z-10"
        >
          <div className="text-sm font-semibold mb-1">⚡ Fast</div>
          <div className="text-xs text-white/50">24hr Delivery</div>
        </motion.div>

        {/* Animated Side Cards - Right */}
        <motion.div
          custom={{ x: 120, y: -100, delay: 0.3 }}
          variants={sideCardVariants}
          initial="hidden"
          animate={["visible", "float"]}
          className="absolute right-6 top-20 md:right-12 md:top-1/4 text-white/70 z-10"
        >
          <div className="text-sm font-semibold mb-1">🔧 Repair</div>
          <div className="text-xs text-white/50">Expert Fix</div>
        </motion.div>

        <motion.div
          custom={{ x: 140, y: 80, delay: 0.5 }}
          variants={sideCardVariants}
          initial="hidden"
          animate={["visible", "float"]}
          className="absolute right-4 bottom-1/4 md:right-8 text-white/70 z-10"
        >
          <div className="text-sm font-semibold mb-1">✓ Trust</div>
          <div className="text-xs text-white/50">5K+ Happy</div>
        </motion.div>

        {/* Center Content */}
        <div className="relative z-20 text-center max-w-5xl mx-auto px-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            <p className="text-white/60 text-lg md:text-xl mb-6 font-medium tracking-wide">
              Unlock Your Tech Potential
            </p>

            <h1 className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-black leading-tight mb-8">
              <span className="text-white">Premium Tech</span>
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary via-secondary to-highlight">
                and Expert Repairs
              </span>
            </h1>

            <p className="text-white/70 text-lg md:text-xl max-w-3xl mx-auto mb-12 font-light">
              Experience cutting-edge technology paired with precision repair services. From premium devices to expert restoration, we've got your tech covered.
            </p>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 justify-center"
            >
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/home')}
                className="px-8 py-3 bg-gradient-to-r from-primary to-secondary text-black font-bold rounded-full text-lg transition-all shadow-[0_0_40px_rgba(247,181,0,0.3)]"
              >
                Shop Now
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => navigate('/repair-home')}
                className="px-8 py-3 bg-transparent border-2 border-white/30 text-white font-bold rounded-full text-lg hover:border-primary/60 hover:bg-white/5 transition-all"
              >
                Book Repair
              </motion.button>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </div>
  );
};

export default Landing;
