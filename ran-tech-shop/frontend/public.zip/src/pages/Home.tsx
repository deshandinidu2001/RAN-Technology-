import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Lenis from 'lenis';

// Import sections
import {
  HeroVideoSection,
  ServicesSection,
  StatsSection,
  ProductShowcase,
  AboutSection,
  TestimonialsSection,
  CTASection,
  BrandsSection,
  RepairSection
} from '../components/home/sections';

gsap.registerPlugin(ScrollTrigger);

// Color palette
const colors = {
  primary: '#F7B500',
  secondary: '#FF6B35',
  accent: '#7C3AED',
  highlight: '#06B6D4',
  dark: '#0A0A0B',
};

const Home = () => {
  const containerRef = useRef<HTMLDivElement>(null);
  const progressRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize Lenis smooth scroll
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      wheelMultiplier: 1,
      touchMultiplier: 2,
    });

    // Integrate Lenis with GSAP ScrollTrigger
    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });

    gsap.ticker.lagSmoothing(0);

    // Scroll progress indicator
    if (progressRef.current && containerRef.current) {
      gsap.to(progressRef.current, {
        scaleX: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top top',
          end: 'bottom bottom',
          scrub: 0.3
        }
      });
    }

    return () => {
      lenis.destroy();
      ScrollTrigger.getAll().forEach(trigger => trigger.kill());
    };
  }, []);

  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="relative min-h-screen overflow-x-hidden"
      style={{ backgroundColor: colors.dark }}
    >
      {/* Scroll Progress Indicator */}
      <div
        ref={progressRef}
        className="fixed top-0 left-0 right-0 h-1 z-[100] origin-left"
        style={{
          background: `linear-gradient(90deg, ${colors.primary}, ${colors.secondary}, ${colors.accent})`,
          transform: 'scaleX(0)'
        }}
      />

      {/* Section 1: Hero Video */}
      <HeroVideoSection />

      {/* Section 2: Brands Marquee */}
      <BrandsSection />

      {/* Section 3: Services Grid */}
      <ServicesSection />

      {/* Section 4: Product Horizontal Scroll */}
      <ProductShowcase />

      {/* Section 5: About Company */}
      <AboutSection />

      {/* Section 6: Repair Services */}
      <RepairSection />

      {/* Section 7: Testimonials */}
      <TestimonialsSection />

      {/* Section 8: Stats Counter */}
      <StatsSection />

      {/* Section 9: Final CTA */}
      <CTASection />
    </motion.div>
  );
};

export default Home;
