import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ProductFilters {
  brands: string[];
  ramTypes: string[];
  ramSpeeds: number[];
  ramCapacities: number[];
  ssdTypes: string[];
  ssdCapacities: number[];
  compatibleLaptops: string[];
}

interface Subcategory {
  slug: string;
  name: string;
  icon: string;
}

interface FilterSidebarProps {
  categories: { name: string; slug: string; count: number }[];
  selectedCategory: string | null;
  onCategoryChange: (category: string | null) => void;
  priceRange: [number, number];
  onPriceRangeChange: (range: [number, number]) => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
  isMobile?: boolean;
  isOpen?: boolean;
  onClose?: () => void;
  // New props for advanced filtering
  subcategories?: Subcategory[];
  selectedSubcategory?: string | null;
  onSubcategoryChange?: (subcategory: string | null) => void;
  filters?: ProductFilters | null;
  selectedBrand?: string | null;
  onBrandChange?: (brand: string | null) => void;
  selectedRamType?: string | null;
  onRamTypeChange?: (ramType: string | null) => void;
  selectedRamSpeed?: number | null;
  onRamSpeedChange?: (ramSpeed: number | null) => void;
  selectedRamCapacity?: number | null;
  onRamCapacityChange?: (ramCapacity: number | null) => void;
  selectedSsdType?: string | null;
  onSsdTypeChange?: (ssdType: string | null) => void;
  selectedSsdCapacity?: number | null;
  onSsdCapacityChange?: (ssdCapacity: number | null) => void;
  selectedCompatibility?: string | null;
  onCompatibilityChange?: (compatibility: string | null) => void;
  onResetFilters?: () => void;
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({
  categories,
  selectedCategory,
  onCategoryChange,
  priceRange,
  onPriceRangeChange,
  sortBy,
  onSortChange,
  isMobile = false,
  isOpen = true,
  onClose,
  subcategories = [],
  selectedSubcategory,
  onSubcategoryChange,
  filters,
  selectedBrand,
  onBrandChange,
  selectedRamType,
  onRamTypeChange,
  selectedRamSpeed,
  onRamSpeedChange,
  selectedRamCapacity,
  onRamCapacityChange,
  selectedSsdType,
  onSsdTypeChange,
  selectedSsdCapacity,
  onSsdCapacityChange,
  selectedCompatibility,
  onCompatibilityChange,
  onResetFilters,
}) => {
  const [localPriceRange, setLocalPriceRange] = useState(priceRange);
  const [expandedSection, setExpandedSection] = useState<string | null>('categories');

  const sortOptions = [
    { value: 'featured', label: 'Featured' },
    { value: 'newest', label: 'Newest First' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'name', label: 'Name: A to Z' },
  ];

  const handlePriceApply = () => {
    onPriceRangeChange(localPriceRange);
  };

  const handleReset = () => {
    onCategoryChange(null);
    onSubcategoryChange?.(null);
    setLocalPriceRange([0, 500000]);
    onPriceRangeChange([0, 500000]);
    onSortChange('featured');
    onResetFilters?.();
  };

  const toggleSection = (section: string) => {
    setExpandedSection(expandedSection === section ? null : section);
  };

  // Check if any spec filters are active
  const hasActiveSpecFilters = selectedBrand || selectedRamType || selectedRamSpeed || 
    selectedRamCapacity || selectedSsdType || selectedSsdCapacity || selectedCompatibility;

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Step 1: Categories */}
      <div className="border-b border-white/10 pb-6">
        <button 
          onClick={() => toggleSection('categories')}
          className="w-full text-lg font-bold text-white mb-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
            Categories
          </div>
          <svg className={`w-5 h-5 transition-transform ${expandedSection === 'categories' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        <AnimatePresence>
          {expandedSection === 'categories' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="space-y-2 overflow-hidden"
            >
              <button
                onClick={() => onCategoryChange(null)}
                className={`w-full px-4 py-2 rounded-lg text-left transition-colors ${
                  selectedCategory === null
                    ? 'bg-primary text-dark font-medium'
                    : 'bg-dark-100 text-white/70 hover:bg-dark-50 hover:text-white'
                }`}
              >
                All Products
              </button>
              {categories.map((category) => (
                <button
                  key={category.slug}
                  onClick={() => onCategoryChange(category.slug)}
                  className={`w-full px-4 py-2 rounded-lg text-left transition-colors flex items-center justify-between ${
                    selectedCategory === category.slug
                      ? 'bg-primary text-dark font-medium'
                      : 'bg-dark-100 text-white/70 hover:bg-dark-50 hover:text-white'
                  }`}
                >
                  <span className="capitalize">{category.name}</span>
                  <span className={`text-sm ${selectedCategory === category.slug ? 'text-dark/60' : 'text-white/40'}`}>
                    {category.count}
                  </span>
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Step 2: Subcategories (only for laptop-accessories) */}
      {selectedCategory === 'laptop-accessories' && subcategories.length > 0 && (
        <div className="border-b border-white/10 pb-6">
          <button 
            onClick={() => toggleSection('subcategories')}
            className="w-full text-lg font-bold text-white mb-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
              </svg>
              Product Type
            </div>
            <svg className={`w-5 h-5 transition-transform ${expandedSection === 'subcategories' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          <AnimatePresence>
            {expandedSection === 'subcategories' && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="space-y-2 overflow-hidden"
              >
                <button
                  onClick={() => onSubcategoryChange?.(null)}
                  className={`w-full px-4 py-2 rounded-lg text-left transition-colors flex items-center gap-2 ${
                    !selectedSubcategory
                      ? 'bg-primary text-dark font-medium'
                      : 'bg-dark-100 text-white/70 hover:bg-dark-50 hover:text-white'
                  }`}
                >
                  <span>🔧</span> All Accessories
                </button>
                {subcategories.map((sub) => (
                  <button
                    key={sub.slug}
                    onClick={() => onSubcategoryChange?.(sub.slug)}
                    className={`w-full px-4 py-2 rounded-lg text-left transition-colors flex items-center gap-2 ${
                      selectedSubcategory === sub.slug
                        ? 'bg-primary text-dark font-medium'
                        : 'bg-dark-100 text-white/70 hover:bg-dark-50 hover:text-white'
                    }`}
                  >
                    <span>{sub.icon}</span> {sub.name}
                  </button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* Step 3: Specifications (only when subcategory is selected) */}
      {selectedCategory === 'laptop-accessories' && selectedSubcategory && filters && (
        <div className="border-b border-white/10 pb-6">
          <button 
            onClick={() => toggleSection('specs')}
            className="w-full text-lg font-bold text-white mb-4 flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
              Specifications
              {hasActiveSpecFilters && (
                <span className="w-2 h-2 bg-primary rounded-full"></span>
              )}
            </div>
            <svg className={`w-5 h-5 transition-transform ${expandedSection === 'specs' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          <AnimatePresence>
            {expandedSection === 'specs' && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="space-y-4 overflow-hidden"
              >
                {/* Brand Filter */}
                {filters.brands.length > 0 && (
                  <div>
                    <label className="text-sm text-white/50 mb-2 block">Brand</label>
                    <select
                      value={selectedBrand || ''}
                      onChange={(e) => onBrandChange?.(e.target.value || null)}
                      className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                    >
                      <option value="">All Brands</option>
                      {filters.brands.map((brand) => (
                        <option key={brand} value={brand}>{brand}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* RAM Filters */}
                {selectedSubcategory === 'ram' && (
                  <>
                    {filters.ramTypes.length > 0 && (
                      <div>
                        <label className="text-sm text-white/50 mb-2 block">Generation</label>
                        <select
                          value={selectedRamType || ''}
                          onChange={(e) => onRamTypeChange?.(e.target.value || null)}
                          className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="">All Types</option>
                          {filters.ramTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {filters.ramSpeeds.length > 0 && (
                      <div>
                        <label className="text-sm text-white/50 mb-2 block">Bus Speed</label>
                        <select
                          value={selectedRamSpeed?.toString() || ''}
                          onChange={(e) => onRamSpeedChange?.(e.target.value ? parseInt(e.target.value) : null)}
                          className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="">All Speeds</option>
                          {filters.ramSpeeds.map((speed) => (
                            <option key={speed} value={speed}>{speed} MHz</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {filters.ramCapacities.length > 0 && (
                      <div>
                        <label className="text-sm text-white/50 mb-2 block">Capacity</label>
                        <select
                          value={selectedRamCapacity?.toString() || ''}
                          onChange={(e) => onRamCapacityChange?.(e.target.value ? parseInt(e.target.value) : null)}
                          className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="">All Capacities</option>
                          {filters.ramCapacities.map((cap) => (
                            <option key={cap} value={cap}>{cap} GB</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </>
                )}

                {/* SSD Filters */}
                {selectedSubcategory === 'ssd' && (
                  <>
                    {filters.ssdTypes.length > 0 && (
                      <div>
                        <label className="text-sm text-white/50 mb-2 block">Type</label>
                        <select
                          value={selectedSsdType || ''}
                          onChange={(e) => onSsdTypeChange?.(e.target.value || null)}
                          className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="">All Types</option>
                          {filters.ssdTypes.map((type) => (
                            <option key={type} value={type}>{type}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {filters.ssdCapacities.length > 0 && (
                      <div>
                        <label className="text-sm text-white/50 mb-2 block">Capacity</label>
                        <select
                          value={selectedSsdCapacity?.toString() || ''}
                          onChange={(e) => onSsdCapacityChange?.(e.target.value ? parseInt(e.target.value) : null)}
                          className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                        >
                          <option value="">All Capacities</option>
                          {filters.ssdCapacities.map((cap) => (
                            <option key={cap} value={cap}>{cap >= 1024 ? `${cap / 1024} TB` : `${cap} GB`}</option>
                          ))}
                        </select>
                      </div>
                    )}
                  </>
                )}

                {/* Compatible Laptops */}
                {filters.compatibleLaptops.length > 0 && (
                  <div>
                    <label className="text-sm text-white/50 mb-2 block">Compatible With</label>
                    <select
                      value={selectedCompatibility || ''}
                      onChange={(e) => onCompatibilityChange?.(e.target.value || null)}
                      className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                    >
                      <option value="">All Laptops</option>
                      {filters.compatibleLaptops.map((laptop) => (
                        <option key={laptop} value={laptop}>{laptop}</option>
                      ))}
                    </select>
                  </div>
                )}

                {/* Active filters */}
                {hasActiveSpecFilters && (
                  <div className="pt-3 border-t border-white/10">
                    <p className="text-white/50 text-xs mb-2">Active filters:</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedBrand && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedBrand}
                          <button onClick={() => onBrandChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedRamType && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedRamType}
                          <button onClick={() => onRamTypeChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedRamSpeed && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedRamSpeed} MHz
                          <button onClick={() => onRamSpeedChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedRamCapacity && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedRamCapacity} GB
                          <button onClick={() => onRamCapacityChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedSsdType && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedSsdType}
                          <button onClick={() => onSsdTypeChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedSsdCapacity && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedSsdCapacity >= 1024 ? `${selectedSsdCapacity / 1024} TB` : `${selectedSsdCapacity} GB`}
                          <button onClick={() => onSsdCapacityChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                      {selectedCompatibility && (
                        <span className="px-2 py-1 bg-primary/20 text-primary rounded text-xs flex items-center gap-1">
                          {selectedCompatibility}
                          <button onClick={() => onCompatibilityChange?.(null)} className="hover:text-white">&times;</button>
                        </span>
                      )}
                    </div>
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      {/* Price Range */}
      <div className="border-b border-white/10 pb-6">
        <button 
          onClick={() => toggleSection('price')}
          className="w-full text-lg font-bold text-white mb-4 flex items-center justify-between"
        >
          <div className="flex items-center gap-2">
            <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Price Range (LKR)
          </div>
          <svg className={`w-5 h-5 transition-transform ${expandedSection === 'price' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        <AnimatePresence>
          {expandedSection === 'price' && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="space-y-4 overflow-hidden"
            >
              <div className="flex items-center gap-4">
                <div className="flex-1">
                  <label className="text-sm text-white/50 mb-1 block">Min</label>
                  <input
                    type="number"
                    value={localPriceRange[0]}
                    onChange={(e) => setLocalPriceRange([Number(e.target.value), localPriceRange[1]])}
                    className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                    min={0}
                  />
                </div>
                <div className="flex-1">
                  <label className="text-sm text-white/50 mb-1 block">Max</label>
                  <input
                    type="number"
                    value={localPriceRange[1]}
                    onChange={(e) => setLocalPriceRange([localPriceRange[0], Number(e.target.value)])}
                    className="w-full px-3 py-2 bg-dark-100 border border-white/10 rounded-lg text-white text-sm focus:outline-none focus:border-primary"
                    min={0}
                  />
                </div>
              </div>

              {/* Range slider */}
              <div className="relative h-2">
                <div className="absolute inset-0 bg-dark-100 rounded-full" />
                <div
                  className="absolute h-full bg-primary rounded-full"
                  style={{
                    left: `${(localPriceRange[0] / 500000) * 100}%`,
                    right: `${100 - (localPriceRange[1] / 500000) * 100}%`,
                  }}
                />
                <input
                  type="range"
                  min={0}
                  max={500000}
                  step={1000}
                  value={localPriceRange[0]}
                  onChange={(e) => setLocalPriceRange([Number(e.target.value), localPriceRange[1]])}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <input
                  type="range"
                  min={0}
                  max={500000}
                  step={1000}
                  value={localPriceRange[1]}
                  onChange={(e) => setLocalPriceRange([localPriceRange[0], Number(e.target.value)])}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
              </div>

              <p className="text-center text-white/50 text-sm">
                Rs. {localPriceRange[0].toLocaleString()} - Rs. {localPriceRange[1].toLocaleString()}
              </p>

              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={handlePriceApply}
                className="w-full py-2 bg-primary/20 text-primary font-medium rounded-lg hover:bg-primary/30 transition-colors"
              >
                Apply Price Filter
              </motion.button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Sort By */}
      <div className="border-b border-white/10 pb-6">
        <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
          <svg className="w-5 h-5 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
          </svg>
          Sort By
        </h3>
        <select
          value={sortBy}
          onChange={(e) => onSortChange(e.target.value)}
          className="w-full px-4 py-3 bg-dark-100 border border-white/10 rounded-lg text-white appearance-none cursor-pointer focus:outline-none focus:border-primary"
          style={{
            backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 24 24' stroke='white'%3E%3Cpath stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M19 9l-7 7-7-7'/%3E%3C/svg%3E")`,
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'right 12px center',
            backgroundSize: '20px',
          }}
        >
          {sortOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      {/* Reset Filters */}
      <motion.button
        whileHover={{ scale: 1.02 }}
        whileTap={{ scale: 0.98 }}
        onClick={handleReset}
        className="w-full py-3 bg-dark-100 text-white/70 font-medium rounded-lg hover:bg-dark-50 hover:text-white transition-colors flex items-center justify-center gap-2"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
        </svg>
        Reset All Filters
      </motion.button>
    </div>
  );

  // Mobile sidebar (slide-in)
  if (isMobile) {
    return (
      <AnimatePresence>
        {isOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={onClose}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40"
            />

            {/* Sidebar */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed left-0 top-0 bottom-0 w-80 bg-dark-200 z-50 overflow-y-auto"
            >
              <div className="sticky top-0 bg-dark-200 px-6 py-4 border-b border-white/5 flex items-center justify-between">
                <h2 className="text-xl font-bold text-white">Filters</h2>
                <button
                  onClick={onClose}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
              <div className="p-6">
                <FilterContent />
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    );
  }

  // Desktop sidebar (static)
  return (
    <div className="bg-dark-200 rounded-2xl p-6 border border-white/5 sticky top-24">
      <FilterContent />
    </div>
  );
};

export default FilterSidebar;
