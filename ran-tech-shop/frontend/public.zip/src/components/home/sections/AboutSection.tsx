import { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BlurText, ScrollFloat, ScrollVelocity } from '../animations';

gsap.registerPlugin(ScrollTrigger);

const aboutFeatures = [
  {
    title: 'Quality First',
    description: 'Every product undergoes rigorous testing before reaching our customers.',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
    ),
    color: '#F7B500'
  },
  {
    title: 'Expert Team',
    description: 'Certified technicians with years of experience in laptop repair.',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />
      </svg>
    ),
    color: '#06B6D4'
  },
  {
    title: 'Fast Service',
    description: 'Same-day repairs and express delivery options available.',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
      </svg>
    ),
    color: '#FF6B35'
  },
  {
    title: 'Warranty',
    description: 'Comprehensive warranty coverage on all products and repairs.',
    icon: (
      <svg className="w-7 h-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
      </svg>
    ),
    color: '#7C3AED'
  }
];

const AboutSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start']
  });

  const imageY = useTransform(scrollYProgress, [0, 1], ['10%', '-10%']);
  const imageScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.9, 1, 0.9]);
  const textX = useTransform(scrollYProgress, [0, 1], ['-5%', '5%']);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Reveal animation for features
      gsap.fromTo('.about-feature',
        { 
          x: -50, 
          opacity: 0 
        },
        {
          x: 0,
          opacity: 1,
          duration: 0.6,
          stagger: 0.15,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.about-features-container',
            start: 'top 75%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Image reveal
      gsap.fromTo(imageRef.current,
        { 
          clipPath: 'polygon(0 0, 0 0, 0 100%, 0 100%)',
          scale: 1.2
        },
        {
          clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
          scale: 1,
          duration: 1.2,
          ease: 'power3.inOut',
          scrollTrigger: {
            trigger: imageRef.current,
            start: 'top 75%',
            toggleActions: 'play none none none'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-32 overflow-hidden bg-gradient-to-b from-[#0A0A0B] via-[#0f0f14] to-[#0A0A0B]"
    >
      {/* Scrolling Text Background */}
      <div className="absolute inset-0 flex flex-col justify-center opacity-5 overflow-hidden">
        <ScrollVelocity
          texts={['RAN TECHNOLOGY', 'INNOVATION', 'QUALITY']}
          velocity={50}
          className="text-white font-black"
        />
      </div>

      {/* Animated Grid */}
      <div className="absolute inset-0 opacity-10">
        <svg className="w-full h-full">
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(247, 181, 0, 0.3)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left Content */}
          <motion.div style={{ x: textX }}>
            <ScrollFloat>
              <motion.p
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-white/50 text-lg mb-4"
              >
                Get to know us better
              </motion.p>
              <h2 className="text-4xl md:text-5xl lg:text-6xl font-black text-white mb-6 leading-tight">
                Your <span className="italic text-[#F7B500]" style={{ fontFamily: 'Georgia, serif' }}>trusted</span> tech partner!
              </h2>
            </ScrollFloat>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.5 }}
              className="text-white/60 text-lg mb-10 leading-relaxed"
            >
              Since 2015, RAN Technology has been at the forefront of delivering premium laptops 
              and expert repair services. Our commitment to quality and customer satisfaction 
              has made us the trusted choice for thousands of customers across the nation.
            </motion.p>

            {/* Features Grid */}
            <div className="about-features-container grid grid-cols-2 gap-4">
              {aboutFeatures.map((feature, index) => (
                <motion.div
                  key={index}
                  className="about-feature"
                  whileHover={{ x: 5 }}
                >
                  <div className="flex items-start gap-3 p-4 bg-white/5 rounded-xl border border-white/10 hover:border-[#F7B500]/30 transition-colors">
                    <span className="flex-shrink-0" style={{ color: feature.color }}>{feature.icon}</span>
                    <div>
                      <h4 className="text-white font-semibold mb-1">{feature.title}</h4>
                      <p className="text-white/50 text-sm">{feature.description}</p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.8 }}
              className="mt-10"
            >
              <motion.a
                href="/about"
                whileHover={{ x: 10 }}
                className="inline-flex items-center gap-3 text-[#F7B500] font-semibold text-lg group"
              >
                Learn More About Us
                <motion.svg 
                  className="w-6 h-6 group-hover:translate-x-2 transition-transform" 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                </motion.svg>
              </motion.a>
            </motion.div>
          </motion.div>

          {/* Right Image */}
          <motion.div 
            ref={imageRef}
            style={{ y: imageY, scale: imageScale }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden">
              {/* About Image - Tech Store/Office */}
              <div className="aspect-[4/5] bg-gradient-to-br from-[#1a1a2e] to-[#0A0A0B] overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1497366216548-37526070297c?w=800&h=1000&fit=crop"
                  alt="RAN Technology HQ"
                  className="w-full h-full object-cover opacity-90"
                  onError={(e) => {
                    (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1497366811353-6870744d04b2?w=800';
                  }}
                />
                {/* Overlay gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B]/80 via-transparent to-transparent" />
                
                {/* Overlay content */}
                <div className="absolute bottom-8 left-8 right-8">
                  <p className="text-white/80 text-lg font-medium">RAN Technology HQ</p>
                  <p className="text-white/50 text-sm">Colombo, Sri Lanka</p>
                </div>
              </div>

              {/* Floating Badge */}
              <motion.div
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 1, type: 'spring' }}
                className="absolute -bottom-6 -left-6 bg-[#F7B500] text-black p-6 rounded-2xl shadow-2xl"
              >
                <p className="text-4xl font-black">10+</p>
                <p className="text-sm font-semibold uppercase tracking-wider">Years Experience</p>
              </motion.div>

              {/* Decorative Lines */}
              <div className="absolute -top-4 -right-4 w-32 h-32 border-t-2 border-r-2 border-[#F7B500]/30 rounded-tr-3xl" />
              <div className="absolute -bottom-4 -left-4 w-32 h-32 border-b-2 border-l-2 border-[#06B6D4]/30 rounded-bl-3xl" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;
