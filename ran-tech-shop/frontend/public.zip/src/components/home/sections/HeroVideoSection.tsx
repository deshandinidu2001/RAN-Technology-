import { useEffect, useRef, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { RotatingText } from '../animations';

gsap.registerPlugin(ScrollTrigger);

const HeroVideoSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const [videoFinished, setVideoFinished] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start']
  });

  const videoOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0.3]);
  const contentY = useTransform(scrollYProgress, [0, 0.5], [0, -100]);
  const scale = useTransform(scrollYProgress, [0, 0.5], [1, 1.1]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Auto-play video on mount
    const playVideo = async () => {
      try {
        await video.play();
        setIsPlaying(true);
      } catch (error) {
        console.error('Video autoplay failed:', error);
      }
    };

    playVideo();

    // Handle video end
    const handleVideoEnd = () => {
      setVideoFinished(true);
      setIsPlaying(false);
    };

    video.addEventListener('ended', handleVideoEnd);

    const ctx = gsap.context(() => {
      // Animate title letters
      if (titleRef.current) {
        const letters = titleRef.current.querySelectorAll('.hero-letter');
        gsap.fromTo(letters, 
          { 
            opacity: 0, 
            y: 100,
            rotateX: -90
          },
          {
            opacity: 1,
            y: 0,
            rotateX: 0,
            duration: 1,
            stagger: 0.05,
            ease: 'power4.out',
            delay: 0.5
          }
        );
      }

      // Parallax effect on scroll
      gsap.to('.hero-gradient', {
        y: 200,
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: 'bottom top',
          scrub: 1
        }
      });

      // Floating particles animation
      gsap.utils.toArray('.hero-particle').forEach((particle: any) => {
        gsap.to(particle, {
          y: 'random(-30, 30)',
          x: 'random(-20, 20)',
          duration: 'random(3, 6)',
          repeat: -1,
          yoyo: true,
          ease: 'sine.inOut'
        });
      });
    }, sectionRef);

    return () => {
      ctx.revert();
      video.removeEventListener('ended', handleVideoEnd);
    };
  }, [videoFinished, isPlaying]);

  // Split text for animation
  const titleText = "Tech";
  const splitTitle = titleText.split('').map((char, i) => (
    <span 
      key={i} 
      className="hero-letter inline-block"
      style={{ display: char === ' ' ? 'inline' : 'inline-block' }}
    >
      {char === ' ' ? '\u00A0' : char}
    </span>
  ));

  return (
    <section
      ref={sectionRef}
      className="relative h-screen w-full overflow-hidden"
    >
      {/* Full Screen Video Background */}
      <motion.div
        className="absolute inset-0 z-0"
        style={{ scale }}
      >
        <video
          ref={videoRef}
          autoPlay
          muted
          playsInline
          className="w-full h-full object-cover"
        >
          <source src="/videos/hero_vedio.mp4" type="video/mp4" />
        </video>
      </motion.div>
      
      {/* Animated Particles */}
      <div className="absolute inset-0 z-[1] pointer-events-none overflow-hidden">
        {Array.from({ length: 30 }).map((_, i) => (
          <div
            key={i}
            className="hero-particle absolute rounded-full"
            style={{
              width: `${Math.random() * 4 + 2}px`,
              height: `${Math.random() * 4 + 2}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              background: i % 3 === 0 ? '#F7B500' : i % 3 === 1 ? '#06B6D4' : '#FF6B35',
              opacity: 0.4 + Math.random() * 0.4
            }}
          />
        ))}
      </div>

      {/* Animated Grid Lines */}
      <div className="absolute inset-0 z-[1] opacity-10">
        <svg className="w-full h-full">
          <defs>
            <pattern id="hero-grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path d="M 60 0 L 0 0 0 60" fill="none" stroke="rgba(247, 181, 0, 0.3)" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hero-grid)" />
        </svg>
      </div>

      {/* Content Container */}
      <motion.div
        ref={contentRef}
        style={{ y: contentY }}
        className="relative z-10 h-full flex items-center"
      >
        <div className="container mx-auto px-6 lg:px-12">
          <div className="max-w-4xl">
            {/* User Count Badge */}
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mb-8 inline-flex items-center gap-3 bg-black/40 backdrop-blur-md border border-[#F7B500]/30 rounded-full px-4 py-2"
            >
              <div className="w-8 h-8 bg-gradient-to-br from-[#F7B500] to-[#FF6B35] rounded-full flex items-center justify-center">
                <svg className="w-5 h-5 text-black" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" />
                </svg>
              </div>
              <div>
                <span className="text-white font-bold text-sm">5000+ Happy Customers</span>
                <br />
                <span className="text-white/70 text-xs">Read Our <span className="underline cursor-pointer hover:text-[#F7B500] transition-colors">Success Stories</span></span>
              </div>
            </motion.div>

            {/* Main Title */}
            <h1 
              ref={titleRef}
              className="text-[120px] md:text-[160px] lg:text-[200px] font-black text-white leading-[0.85] mb-8"
              style={{ 
                perspective: '1000px',
                fontFamily: 'system-ui, -apple-system, sans-serif',
                letterSpacing: '-0.03em',
                textShadow: '0 4px 20px rgba(0, 0, 0, 0.5)'
              }}
            >
              {splitTitle}<sup className="text-[80px] md:text-[100px] lg:text-[120px] font-normal align-super text-[#F7B500]">+</sup>
            </h1>

            {/* Subtitle */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 1.0, duration: 0.8 }}
              className="text-xl md:text-2xl lg:text-3xl font-normal text-white/90 leading-relaxed mb-8 max-w-3xl"
              style={{ 
                fontFamily: 'system-ui, -apple-system, sans-serif',
                textShadow: '0 2px 10px rgba(0, 0, 0, 0.5)'
              }}
            >
              Premium Laptops, Expert Repairs, And Tech Solutions — Your Complete Technology Partner.
            </motion.p>

            {/* Testimonial Section */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 1.3 }}
              className="flex items-center gap-4 mb-10"
            >
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-full overflow-hidden border-2 border-[#F7B500] shadow-lg">
                  <div className="w-full h-full bg-gradient-to-br from-[#FF6B35] to-[#F7B500]" />
                </div>
                <div>
                  <p className="text-sm text-white font-medium">Best laptop deals ever</p>
                  <p className="text-xs text-white/60">100% Satisfied</p>
                </div>
              </div>
              <div className="flex items-center gap-1 bg-[#F7B500]/20 backdrop-blur-sm px-3 py-1 rounded-full border border-[#F7B500]/30">
                <svg className="w-4 h-4 text-[#F7B500]" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
                <span className="text-sm font-bold text-white">4.9</span>
              </div>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.6 }}
              className="flex flex-wrap items-center gap-6"
            >
              <motion.a
                href="/shop"
                whileHover={{ scale: 1.05, boxShadow: '0 0 40px rgba(247, 181, 0, 0.5)' }}
                whileTap={{ scale: 0.95 }}
                className="group relative px-8 py-4 bg-gradient-to-r from-[#F7B500] to-[#FF6B35] text-black font-bold rounded-full text-base overflow-hidden inline-flex items-center gap-2 shadow-xl"
              >
                Shop Now — Best Prices
              </motion.a>
              <motion.a
                href="/repair"
                whileHover={{ x: 5 }}
                className="text-white font-medium text-base inline-flex items-center gap-2 hover:text-[#F7B500] transition-colors"
              >
                Book Repair 
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </motion.a>
            </motion.div>
          </div>
        </div>
      </motion.div>

      {/* Video Progress Indicator */}
      {isPlaying && !videoFinished && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="absolute top-8 left-1/2 -translate-x-1/2 z-20 flex items-center gap-3 bg-black/50 backdrop-blur-sm px-6 py-3 rounded-full border border-[#F7B500]/30"
        >
          <div className="w-32 h-1.5 bg-white/20 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-gradient-to-r from-[#F7B500] to-[#FF6B35]"
              style={{
                width: videoRef.current ? `${(videoRef.current.currentTime / videoRef.current.duration) * 100}%` : '0%'
              }}
            />
          </div>
          <span className="text-xs text-white/70 font-semibold">Playing</span>
        </motion.div>
      )}

      {/* Scroll Indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2.5 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10"
      >
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ duration: 2, repeat: Infinity }}
          className="flex flex-col items-center gap-2 text-white/50"
        >
          <span className="text-xs uppercase tracking-[0.2em]">Scroll</span>
          <motion.div className="w-5 h-8 border border-white/30 rounded-full flex justify-center pt-1.5">
            <motion.div
              animate={{ y: [0, 10, 0], opacity: [1, 0.3, 1] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="w-1 h-1 bg-[#F7B500] rounded-full"
            />
          </motion.div>
        </motion.div>
      </motion.div>

      {/* Decorative Corner Elements */}
      <div className="absolute top-4 right-4 flex gap-2 z-10">
        {[1, 2, 3].map((_, i) => (
          <motion.div
            key={i}
            initial={{ scaleY: 0 }}
            animate={{ scaleY: 1 }}
            transition={{ delay: 0.5 + i * 0.1, duration: 0.8 }}
            className="w-1 bg-gradient-to-b from-white/30 to-transparent origin-top"
            style={{ height: `${60 - i * 15}px` }}
          />
        ))}
      </div>
    </section>
  );
};

export default HeroVideoSection;
