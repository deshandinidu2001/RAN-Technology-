import { useRef, useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BlurText, ScrollFloat, TiltedCard } from '../animations';
import api from '../../../utils/api';

gsap.registerPlugin(ScrollTrigger);

interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  image: string;
  specs: string;
  category: string;
}

const fallbackProducts = [
  {
    id: 1,
    name: 'MacBook Pro 16"',
    brand: 'Apple',
    price: 450000,
    image: '/images/products/macbook.jpg',
    specs: JSON.stringify({'Chip': 'M3 Max', 'RAM': '48GB', 'Storage': '1TB SSD'}),
    category: 'laptops'
  },
  {
    id: 2,
    name: 'ROG Zephyrus G16',
    brand: 'ASUS',
    price: 380000,
    image: '/images/products/rog.jpg',
    specs: JSON.stringify({'GPU': 'RTX 4080', 'CPU': 'i9-14900H', 'RAM': '32GB DDR5'}),
    category: 'laptops'
  },
  {
    id: 3,
    name: 'ThinkPad X1 Carbon',
    brand: 'Lenovo',
    price: 290000,
    image: '/images/products/thinkpad.jpg',
    specs: JSON.stringify({'CPU': 'i7-1365U', 'RAM': '16GB', 'Storage': '512GB SSD'}),
    category: 'laptops'
  },
  {
    id: 4,
    name: 'XPS 15 OLED',
    brand: 'Dell',
    price: 320000,
    image: '/images/products/xps.jpg',
    specs: JSON.stringify({'CPU': 'i7-13700H', 'RAM': '32GB', 'Display': '3.5K OLED'}),
    category: 'laptops'
  }
];

const brandColors: { [key: string]: string } = {
  'Apple': 'from-gray-900 to-gray-700',
  'ASUS': 'from-red-900 to-red-700',
  'Lenovo': 'from-black to-gray-800',
  'Dell': 'from-blue-900 to-blue-700',
  'HP': 'from-cyan-900 to-cyan-700',
  'MSI': 'from-red-800 to-orange-700',
  'Acer': 'from-green-900 to-green-700',
  'NVIDIA': 'from-lime-900 to-lime-700',
  'AMD': 'from-red-900 to-red-600',
  'default': 'from-purple-900 to-purple-700'
};

const ProductShowcase = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const sliderRef = useRef<HTMLDivElement>(null);
  const [activeIndex] = useState(0);
  const [products, setProducts] = useState<Product[]>(fallbackProducts);
  const [loading, setLoading] = useState(true);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start']
  });

  const translateX = useTransform(scrollYProgress, [0, 1], ['0%', '-20%']);

  // Fetch products from API
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await api.get('/products?featured=true&limit=6');
        if (response.data && response.data.length > 0) {
          setProducts(response.data.slice(0, 6));
        }
      } catch (error) {
        console.log('Using fallback products');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  useEffect(() => {
    if (loading) return;
    
    const ctx = gsap.context(() => {
      // Horizontal scroll effect
      gsap.to(sliderRef.current, {
        x: () => -(sliderRef.current!.scrollWidth - window.innerWidth + 100),
        ease: 'none',
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top top',
          end: () => `+=${sliderRef.current!.scrollWidth}`,
          pin: true,
          scrub: 1,
          anticipatePin: 1
        }
      });

      // Scale animation on cards
      gsap.utils.toArray('.product-card').forEach((card: any) => {
        gsap.fromTo(card,
          { scale: 0.9, opacity: 0.5 },
          {
            scale: 1,
            opacity: 1,
            scrollTrigger: {
              trigger: card,
              start: 'left center',
              end: 'right center',
              scrub: true
            }
          }
        );
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [loading]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden bg-[#0A0A0B]"
    >
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-0 w-full h-32 bg-gradient-to-b from-[#0A0A0B] to-transparent z-10" />
        <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-[#0A0A0B] to-transparent z-10" />
        
        {/* Animated gradient */}
        <motion.div 
          className="absolute inset-0"
          style={{ x: translateX }}
        >
          <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-purple-500/10 rounded-full blur-[200px]" />
          <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-cyan-500/10 rounded-full blur-[200px]" />
        </motion.div>
      </div>

      {/* Header */}
      <div className="absolute top-8 left-0 right-0 z-20 container mx-auto px-6">
        <ScrollFloat>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-white/50 text-lg mb-4"
          >
            H
          </motion.p>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-black text-white flex flex-wrap justify-center gap-x-2">
            <span>Our</span>
            <span className="italic text-[#F7B500]" style={{ fontFamily: 'Georgia, serif' }}>premium</span>
            <span>products!</span>
          </h2>
        </ScrollFloat>
      </div>

      {/* Horizontal Scroll Container */}
      <div 
        ref={sliderRef}
        className="absolute top-1/2 -translate-y-1/2 flex items-center gap-8 pl-12"
        style={{ left: '100px' }}
      >
        {products.map((product) => {
          const specs = typeof product.specs === 'string' ? JSON.parse(product.specs) : product.specs;
          const specEntries = Object.entries(specs).slice(0, 3);
          const color = brandColors[product.brand] || brandColors['default'];
          
          return (
            <motion.div
              key={product.id}
              className="product-card flex-shrink-0 w-[400px] md:w-[500px]"
            >
              <TiltedCard
                className="w-full"
                maxTilt={8}
                scale={1.02}
                glareEnable={true}
              >
                <div className={`relative bg-gradient-to-br ${color} rounded-3xl p-8 overflow-hidden min-h-[500px]`}>
                  {/* Decorative Elements */}
                  <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2" />
                  <div className="absolute bottom-0 left-0 w-32 h-32 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />

                  {/* Brand Badge */}
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="absolute top-6 right-6 bg-white/10 backdrop-blur-sm px-4 py-2 rounded-full"
                  >
                    <span className="text-white/80 text-sm font-medium">{product.brand}</span>
                  </motion.div>

                  {/* Product Image */}
                  <div className="relative h-48 mb-8 flex items-center justify-center">
                    <motion.div
                      whileHover={{ y: -10, rotateY: 10 }}
                      transition={{ type: 'spring', stiffness: 300 }}
                      className="w-full h-full bg-gradient-to-br from-white/20 to-white/5 rounded-2xl flex items-center justify-center overflow-hidden"
                    >
                      <img 
                        src={product.image} 
                        alt={product.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800';
                        }}
                      />
                    </motion.div>
                  </div>

                  {/* Content */}
                  <div className="relative z-10">
                    <h3 className="text-2xl font-bold text-white mb-2">
                      {product.name}
                    </h3>
                    
                    {/* Specs */}
                    <div className="flex flex-wrap gap-2 mb-6">
                      {specEntries.map(([key, value], i) => (
                        <span
                          key={i}
                          className="bg-white/10 text-white/70 text-xs px-3 py-1 rounded-full"
                        >
                          {key}: {String(value)}
                        </span>
                      ))}
                    </div>

                    {/* Price and CTA */}
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-white/50 text-sm">Starting from</p>
                        <p className="text-2xl font-black text-[#F7B500]">
                          Rs. {product.price.toLocaleString()}
                        </p>
                      </div>
                      <motion.a
                        href={`/products/${product.id}`}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="bg-white text-black px-6 py-3 rounded-full font-bold text-sm uppercase tracking-wider"
                      >
                        View Details
                      </motion.a>
                    </div>
                  </div>
                </div>
              </TiltedCard>
            </motion.div>
          );
        })}

        {/* View All CTA */}
        <motion.div className="flex-shrink-0 w-[300px] flex items-center justify-center">
          <motion.a
            href="/shop"
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.95 }}
            className="flex flex-col items-center gap-4 text-white/60 hover:text-white transition-colors"
          >
            <div className="w-24 h-24 rounded-full border-2 border-current flex items-center justify-center">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
              </svg>
            </div>
            <span className="text-lg font-semibold">View All Products</span>
          </motion.a>
        </motion.div>
      </div>

      {/* Progress Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-2">
        {products.map((_, index) => (
          <motion.div
            key={index}
            className={`w-2 h-2 rounded-full ${
              index === activeIndex ? 'bg-[#F7B500]' : 'bg-white/30'
            }`}
            whileHover={{ scale: 1.5 }}
          />
        ))}
      </div>
    </section>
  );
};

export default ProductShowcase;
