import { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { BlurText, ScrollFloat } from '../animations';

gsap.registerPlugin(ScrollTrigger);

// SVG Icons for brands
const BrandIcon = ({ name }: { name: string }) => {
  const iconMap: { [key: string]: JSX.Element } = {
    Apple: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.81-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
      </svg>
    ),
    ASUS: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M23.904 10.788L12 2.4.096 10.788l.72.936L12 4.056l11.184 7.668.72-.936zM12 6l-9 6.18V18h18v-5.82L12 6zm6.6 10.2H5.4v-3.48L12 8.52l6.6 4.2v3.48z"/>
      </svg>
    ),
    Dell: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm0 2.4A9.6 9.6 0 1 1 2.4 12 9.6 9.6 0 0 1 12 2.4zm-2.88 5.04v9.12h2.4v-3.6h1.2c2.16 0 3.6-1.44 3.6-3.6 0-1.2-.96-1.92-2.88-1.92H9.12zm2.4 1.92h.96c.72 0 1.2.24 1.2.72 0 .72-.48 1.08-1.44 1.08h-.72V9.36z"/>
      </svg>
    ),
    HP: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm-.663 4.494h1.794l-2.568 7.506h2.016l-1.26 3.006H9.303l1.26-3.006H8.547l2.79-7.506zm3.879 0h2.016l-2.79 7.506h2.016l-1.26 3.006h-2.016l1.26-3.006h-2.016l2.79-7.506z"/>
      </svg>
    ),
    Lenovo: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M20.4 7.2H3.6c-.996 0-1.8.804-1.8 1.8v6c0 .996.804 1.8 1.8 1.8h16.8c.996 0 1.8-.804 1.8-1.8V9c0-.996-.804-1.8-1.8-1.8zm-14.88 7.32H4.2V9.48h1.32v5.04zm2.76-3.72c-.6 0-.96.36-.96.84 0 .48.36.84.96.84s.96-.36.96-.84c0-.48-.36-.84-.96-.84zm0 2.52c-1.08 0-1.92-.6-1.92-1.68s.84-1.68 1.92-1.68 1.92.6 1.92 1.68-.84 1.68-1.92 1.68zm4.44 1.2h-1.32v-3.6l-1.2 3.6h-.84l-1.2-3.6v3.6h-.72V9.48h1.56l.96 2.88.96-2.88h1.8v5.04zm3.12-3.72c-.6 0-.96.36-.96.84 0 .48.36.84.96.84s.96-.36.96-.84c0-.48-.36-.84-.96-.84zm0 2.52c-1.08 0-1.92-.6-1.92-1.68s.84-1.68 1.92-1.68 1.92.6 1.92 1.68-.84 1.68-1.92 1.68zm3.36 1.2l-1.44-5.04h1.44l.72 3.12.72-3.12h1.44l-1.44 5.04h-1.44z"/>
      </svg>
    ),
    MSI: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M2.4 6v12h19.2V6H2.4zm17.28 9.84H4.32V8.16h15.36v7.68zM6.96 10.8v2.4l1.2-1.2-1.2-1.2zm3.12 0l1.2 1.2-1.2 1.2v-2.4zm3.84 2.4l-1.2-1.2 1.2-1.2v2.4zm1.2-2.4v2.4l1.2-1.2-1.2-1.2z"/>
      </svg>
    ),
    Acer: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M12.61 11.08L9.51 5.47H7.15l4.12 7.14h2.68l4.12-7.14h-2.36l-3.1 5.61zm-8.18 1.86c-.38 0-.69.31-.69.69v4.9c0 .38.31.69.69.69h15.14c.38 0 .69-.31.69-.69v-4.9c0-.38-.31-.69-.69-.69H4.43z"/>
      </svg>
    ),
    Microsoft: (
      <svg viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M11.4 11.4H0V0h11.4v11.4zm12.6 0H12.6V0H24v11.4zM11.4 24H0V12.6h11.4V24zm12.6 0H12.6V12.6H24V24z"/>
      </svg>
    )
  };
  return iconMap[name] || <span className="text-2xl text-[#F7B500]">●</span>;
};

const brands = [
  { name: 'Apple', color: '#F7B500' },
  { name: 'ASUS', color: '#06B6D4' },
  { name: 'Dell', color: '#7C3AED' },
  { name: 'HP', color: '#F7B500' },
  { name: 'Lenovo', color: '#06B6D4' },
  { name: 'MSI', color: '#FF6B35' },
  { name: 'Acer', color: '#7C3AED' },
  { name: 'Microsoft', color: '#06B6D4' }
];

const BrandsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const inclinedRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start']
  });

  // Transform for inclined scroll effect
  const rotate = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 0, 0, 0]);
  const x1 = useTransform(scrollYProgress, [0, 1], ['20%', '-80%']);
  const x2 = useTransform(scrollYProgress, [0, 1], ['-80%', '20%']);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Continuous scroll animation for tracks
      gsap.to('.brand-track-1', {
        x: '-50%',
        duration: 25,
        repeat: -1,
        ease: 'linear'
      });

      gsap.to('.brand-track-2', {
        x: '50%',
        duration: 25,
        repeat: -1,
        ease: 'linear'
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative py-32 overflow-hidden bg-gradient-to-b from-[#0A0A0B] to-[#0f0f14]"
    >
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div 
          className="w-full h-full"
          style={{
            backgroundImage: `linear-gradient(45deg, white 1px, transparent 1px)`,
            backgroundSize: '40px 40px'
          }}
        />
      </div>

      {/* Glow Effects */}
      <div className="absolute top-1/2 left-1/4 w-96 h-96 bg-[#F7B500]/10 rounded-full blur-[150px]" />
      <div className="absolute bottom-1/2 right-1/4 w-96 h-96 bg-[#06B6D4]/10 rounded-full blur-[150px]" />

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        {/* Section Header */}
        <ScrollFloat className="text-center mb-20">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-[#06B6D4] font-semibold tracking-[0.3em] uppercase mb-4"
          >
            Trusted Partners
          </motion.p>
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-black text-white flex flex-wrap justify-center gap-x-2">
            <span>Premium</span>
            <span className="italic text-[#F7B500]" style={{ fontFamily: 'Georgia, serif' }}>brands</span>
            <span>we carry!</span>
          </h2>
        </ScrollFloat>
      </div>

      {/* Inclined Scrolling Brand Tracks */}
      <motion.div 
        ref={inclinedRef}
        className="relative -mx-32"
        style={{ rotate }}
      >
        {/* Track 1 - Scrolls Left */}
        <motion.div 
          className="relative mb-6 overflow-visible py-4"
          style={{ x: x1 }}
        >
          <div className="brand-track-1 flex gap-6">
            {[...brands, ...brands, ...brands, ...brands].map((brand, index) => (
              <motion.div
                key={`t1-${index}`}
                className="flex-shrink-0"
                whileHover={{ scale: 1.1, y: -5, zIndex: 10 }}
              >
                <div 
                  className="w-40 h-24 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2 hover:border-[#F7B500]/50 transition-all duration-300 hover:bg-white/10"
                >
                  <div style={{ color: brand.color }} className="transition-transform duration-300">
                    <BrandIcon name={brand.name} />
                  </div>
                  <span className="text-white/70 text-sm font-medium">{brand.name}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Track 2 - Scrolls Right */}
        <motion.div 
          className="relative overflow-visible py-4"
          style={{ x: x2 }}
        >
          <div className="brand-track-2 flex gap-6">
            {[...brands.slice().reverse(), ...brands.slice().reverse(), ...brands.slice().reverse(), ...brands.slice().reverse()].map((brand, index) => (
              <motion.div
                key={`t2-${index}`}
                className="flex-shrink-0"
                whileHover={{ scale: 1.1, y: -5, zIndex: 10 }}
              >
                <div 
                  className="w-40 h-24 bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex flex-col items-center justify-center gap-2 hover:border-[#06B6D4]/50 transition-all duration-300 hover:bg-white/10"
                >
                  <div style={{ color: brand.color }} className="transition-transform duration-300">
                    <BrandIcon name={brand.name} />
                  </div>
                  <span className="text-white/70 text-sm font-medium">{brand.name}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </motion.div>

      {/* Gradient Overlays for smooth edges */}
      <div className="absolute left-0 top-0 bottom-0 w-48 bg-gradient-to-r from-[#0A0A0B] via-[#0A0A0B]/80 to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-48 bg-gradient-to-l from-[#0f0f14] via-[#0f0f14]/80 to-transparent z-10 pointer-events-none" />
    </section>
  );
};

export default BrandsSection;