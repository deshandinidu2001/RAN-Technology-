import { useRef, useEffect } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const testimonials = [
  {
    id: 1,
    name: 'Ashan Perera',
    handle: '@Ashan_Perera',
    initials: 'AP',
    text: "Overall, I really like RAN Technology. It's easy to find what I need and has everything for my tech needs. However, there are a couple of areas where improvements could be made, like adding more customization options. Still, it's one of the better laptop shops out there.",
    color: '#7C3AED'
  },
  {
    id: 2,
    name: 'Sachini Fernando',
    handle: '@Sachini_Fernando',
    initials: 'SF',
    text: "I've been shopping at RAN Technology for a few months now, and I must say it's incredibly easy to navigate. Finding laptops, checking prices, and getting support all take just a few clicks.",
    color: '#F7B500'
  },
  {
    id: 3,
    name: 'Kamal Silva',
    handle: '@Kamal_Silva',
    initials: 'KS',
    text: "RAN Technology has one of the cleanest and most intuitive interfaces I've seen in a tech shop. Everything is organized well, and it's super easy to find what I need. Love how quickly I can make purchases!",
    color: '#06B6D4'
  },
  {
    id: 4,
    name: 'Dilini Jayawardena',
    handle: '@Dilini_J',
    initials: 'DJ',
    text: "As a student, I needed an affordable yet powerful laptop. The team at RAN Technology helped me find the perfect balance. Their student discount was a huge bonus! Highly recommend to everyone.",
    color: '#FF6B35'
  }
];

const TestimonialsSection = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsContainerRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start']
  });

  // Parallax transforms
  const backgroundY = useTransform(scrollYProgress, [0, 1], ['0%', '20%']);
  const titleScale = useTransform(scrollYProgress, [0, 0.3], [0.9, 1]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Title word animation on scroll
      if (titleRef.current) {
        const words = titleRef.current.querySelectorAll('.title-word');
        gsap.fromTo(words,
          { y: 100, opacity: 0, rotateX: -90 },
          {
            y: 0,
            opacity: 1,
            rotateX: 0,
            duration: 1,
            stagger: 0.12,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: titleRef.current,
              start: 'top 85%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      }

      // Cards scroll reveal animation - each card appears when scrolled into view
      gsap.utils.toArray('.testimonial-card').forEach((card: any, i) => {
        gsap.fromTo(card,
          { 
            y: 80, 
            opacity: 0,
            scale: 0.95
          },
          {
            y: 0,
            opacity: 1,
            scale: 1,
            duration: 0.8,
            ease: 'power3.out',
            scrollTrigger: {
              trigger: card,
              start: 'top 90%',
              end: 'top 60%',
              toggleActions: 'play none none reverse'
            }
          }
        );
      });

      // Subtitle animation
      gsap.fromTo('.testimonial-subtitle',
        { y: 30, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.testimonial-subtitle',
            start: 'top 90%',
            toggleActions: 'play none none reverse'
          }
        }
      );

      // Bottom section animation
      gsap.fromTo('.testimonial-bottom',
        { y: 40, opacity: 0 },
        {
          y: 0,
          opacity: 1,
          duration: 0.8,
          ease: 'power3.out',
          scrollTrigger: {
            trigger: '.testimonial-bottom',
            start: 'top 95%',
            toggleActions: 'play none none reverse'
          }
        }
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  // Split title into words for animation
  const titleWords = ['What', 'our'];
  const highlightWord = 'amazing';
  const titleWords2 = ['customers', 'are', 'saying!'];

  return (
    <section
      ref={sectionRef}
      className="relative py-32 overflow-hidden bg-[#0A0A0B]"
    >
      {/* Animated Background Elements - Dark Theme */}
      <motion.div className="absolute inset-0" style={{ y: backgroundY }}>
        <div className="absolute top-20 left-[10%] w-72 h-72 bg-[#7C3AED]/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-20 right-[10%] w-96 h-96 bg-[#06B6D4]/10 rounded-full blur-[140px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gradient-to-br from-[#F7B500]/5 to-transparent rounded-full blur-[150px]" />
      </motion.div>

      {/* Grid Pattern */}
      <div 
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
          backgroundSize: '60px 60px'
        }}
      />

      <div className="container mx-auto px-6 lg:px-12 relative z-10">
        {/* Section Header */}
        <motion.div 
          className="text-center mb-16"
          style={{ scale: titleScale }}
        >
          <motion.h2
            ref={titleRef}
            className="text-4xl md:text-6xl lg:text-7xl font-black text-white leading-tight"
            style={{ perspective: '1000px' }}
          >
            <span className="inline-block overflow-hidden">
              {titleWords.map((word, i) => (
                <span key={i} className="title-word inline-block mr-4" style={{ transformStyle: 'preserve-3d' }}>
                  {word}
                </span>
              ))}
            </span>
            <span 
              className="title-word inline-block mr-4 italic text-[#F7B500]"
              style={{ 
                fontFamily: 'Georgia, serif',
                fontStyle: 'italic',
                transformStyle: 'preserve-3d'
              }}
            >
              {highlightWord}
            </span>
            <br className="hidden md:block" />
            <span className="inline-block overflow-hidden">
              {titleWords2.map((word, i) => (
                <span key={i} className="title-word inline-block mr-4" style={{ transformStyle: 'preserve-3d' }}>
                  {word}
                </span>
              ))}
            </span>
          </motion.h2>
          
          <p className="testimonial-subtitle text-white/50 text-lg mt-6 max-w-xl mx-auto">
            Real experiences from our valued customers across Sri Lanka
          </p>
        </motion.div>

        {/* Testimonial Cards - Twitter/X Style Dark Theme */}
        <div 
          ref={cardsContainerRef}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-6xl mx-auto"
        >
          {testimonials.slice(0, 3).map((testimonial) => (
            <div
              key={testimonial.id}
              className="testimonial-card"
            >
              <div className="bg-[#16161a] rounded-3xl p-6 border border-white/10 h-full flex flex-col hover:border-white/20 transition-colors duration-300">
                {/* Header with Avatar and X Icon */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    {/* Avatar */}
                    <div
                      className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-lg"
                      style={{ backgroundColor: testimonial.color }}
                    >
                      {testimonial.initials}
                    </div>
                    {/* Name & Handle */}
                    <div>
                      <h4 className="font-bold text-white text-sm">{testimonial.name}</h4>
                      <p className="text-white/40 text-xs">{testimonial.handle}</p>
                    </div>
                  </div>
                  {/* X (Twitter) Icon */}
                  <div className="text-white/30 hover:text-white/60 transition-colors cursor-pointer">
                    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                    </svg>
                  </div>
                </div>

                {/* Quote Text */}
                <p className="text-white/70 text-sm leading-relaxed flex-1">
                  "{testimonial.text}"
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Section */}
        <div className="testimonial-bottom flex items-center justify-between max-w-6xl mx-auto mt-10 px-4">
          {/* Read More Link */}
          <a
            href="#"
            className="inline-flex items-center gap-2 text-white/60 font-semibold text-sm hover:text-[#F7B500] transition-colors group"
          >
            Read more stories
            <svg 
              className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 17L17 7M17 7H7M17 7v10" />
            </svg>
          </a>

          {/* Avatar Stack */}
          <div className="flex items-center">
            <div className="flex -space-x-3">
              {testimonials.map((t, i) => (
                <div
                  key={t.id}
                  className="w-10 h-10 rounded-full border-2 border-[#0A0A0B] flex items-center justify-center text-white text-xs font-bold shadow-md"
                  style={{ backgroundColor: t.color, zIndex: testimonials.length - i }}
                >
                  {t.initials}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;